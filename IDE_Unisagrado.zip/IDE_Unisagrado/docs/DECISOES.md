# Decisões

- **05/11/2026 — Pasta do projeto:** o repositório estava vazio, salvo a especificação. Foi usada a pasta atual como raiz, evitando um diretório adicional.
- **05/11/2026 — Compatibilidade de versões:** Vite 6 e plugin React 4 preservam suporte ao Node 20 inicial. Vitest 4.1.12 declara suporte a Node 20 e corrige os alertas encontrados. As versões efetivas estão no package-lock.json.
- **05/11/2026 — Git ausente:** foi obtido Git portátil em .tools, pasta ignorada. Os commits usam a identidade técnica fictícia local CotaLog Agent <cotalog-agent@example.invalid>, sem alterar a configuração global do usuário.
- **06/11/2026 — Nomes com acentos:** o NOCASE nativo do SQLite compara apenas ASCII. A aplicação também compara os nomes com conversão Unicode para minúsculas em pt-BR, preservando o schema exigido e a unicidade sem diferenciar maiúsculas e minúsculas.
- **06/11/2026 — Timestamps e CSV:** os defaults do schema SQLite são mantidos e convertidos para ISO 8601 UTC na API. A coluna Criado em exporta somente a data UTC do registro, em dd/mm/aaaa, pois não foi especificado formato de hora para o CSV.
- **06/11/2026 — Etapa inicial e final simultâneas:** uma requisição que atribui as duas marcas à mesma etapa retorna 400 com erro de campo; a transação preserva a configuração anterior, mantendo uma etapa de cada tipo.
