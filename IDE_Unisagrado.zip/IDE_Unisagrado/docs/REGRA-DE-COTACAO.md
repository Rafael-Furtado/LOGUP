# Regra de cotação

Cada regra atende a uma transportadora, uma região de destino e uma faixa `(minWeightKg, maxWeightKg]`: o mínimo é exclusivo e o máximo é inclusivo. As faixas 0–10 e 10–50 são adjacentes e válidas. Há sobreposição quando `A.min < B.max && B.min < A.max`; o backend a rejeita com erro de campo.

A origem e o volume do pedido são apenas informativos. Somente transportadoras ativas participam de novas rodadas.

## Fórmula e arredondamento

```js
weightGrams = Math.round(weightKg * 1000)
variableCents = Math.floor((weightGrams * pricePerKgCents + 500) / 1000)
priceCents = Math.max(minChargeCents, variableCents) + fixedFeeCents
```

Dinheiro é inteiro em centavos. O peso do pedido tem no máximo três casas decimais. O acréscimo de 500 antes da divisão por 1000 faz o arredondamento meio-para-cima usando aritmética inteira.

`estimatedDeliveryDate` é a data da cotação, no fuso de São Paulo, somada a `leadTimeDays` em **dias corridos**. `meetsDeadline` compara a entrega estimada com o prazo desejado e é recalculado na leitura. Alterar somente o prazo desejado mantém a rodada e atualiza sua indicação de atendimento.

## Indisponibilidade, selos e ordenação

- Sem regras para a região: **Sem tabela para a região de destino**.
- Com regras na região, mas sem faixa que atenda ao peso: **Peso fora das faixas cadastradas**.
- Entre as disponíveis, menor valor recebe `cheapest` (Mais barata), e menor prazo recebe `fastest` (Mais rápida). Todas as empatadas recebem os selos correspondentes.
- Disponíveis aparecem primeiro por valor, prazo e nome; indisponíveis vêm depois, por nome.
- Sem opção disponível dentro do prazo, a interface avisa: **Nenhuma transportadora atende ao prazo desejado.** Uma opção fora do prazo pode ser selecionada após confirmação.

A recotação substitui toda a rodada e remove a seleção anterior. O nome da transportadora é gravado como cópia na cotação: uma renomeação posterior preserva o nome da rodada já registrada.

## Exemplos oficiais

Para os exemplos abaixo, hoje é `2026-11-10`. Preços e dias são os do seed fictício.

| Exemplo | Alfa Transportes | Beta Express | Gama Cargas | Delta Log |
|---|---|---|---|---|
| E1 — Sudeste, 20 kg | R$ 72,00 / 3 dias | R$ 82,00 / 2 dias | R$ 63,00 / 5 dias | R$ 70,00 / 4 dias |
| E2 — Sudeste, 5 kg | R$ 53,00 / 3 dias | R$ 52,00 / 2 dias | R$ 55,00 / 5 dias | R$ 48,00 / 4 dias |
| E3 — Nordeste, 300 kg | R$ 791,00 / 6 dias | Peso fora das faixas cadastradas | R$ 701,00 / 8 dias | R$ 838,00 / 7 dias |
| E4 — Norte, 15 kg | R$ 89,60 / 8 dias | R$ 101,25 / 7 dias | R$ 78,95 / 10 dias | Sem tabela para a região de destino |
| E5 — Sudeste, 60 kg, prazo 14/11/2026 | R$ 152,00 / 3 dias | R$ 138,00 / 2 dias | R$ 143,00 / 5 dias | R$ 142,00 / 4 dias |

- **E1:** Gama é a mais barata e Beta a mais rápida. Alfa: `max(4500, 20 × 320) + 800 = 7200` centavos.
- **E2:** os mínimos prevalecem; Delta é a mais barata, Beta a mais rápida.
- **E3:** Gama é a mais barata e Alfa a mais rápida. Para Delta, o preço por kg é `Math.round(190 × 145 / 100) = 276`; `300 × 276 + 1000 = 83800` centavos. Beta não possui a quarta faixa.
- **E4:** Gama é a mais barata e Beta a mais rápida; Delta não tem tabela para Norte.
- **E5:** Beta recebe ambos os selos. Gama entrega em 15/11/2026, após o prazo de 14/11/2026; as outras três atendem ao prazo.
- **E6:** 12,345 kg a 368 centavos/kg: `weightGrams = 12345`; `Math.floor((12345 × 368 + 500) / 1000) = 4543` centavos (R$ 45,43), antes de mínimo e taxa fixa.

As regras regionais aplicam o percentual ao preço base por kg, com arredondamento meio-para-cima, e adicionam os dias extras. Os mínimos e as taxas fixas permanecem iguais entre regiões. Beta não tem a faixa `(200, 1000]`; Delta não tem regras para Norte.
