import { useEffect } from 'react';
import Orders from './pages/Orders.jsx';
import OrderForm from './pages/OrderForm.jsx';
import OrderDetail from './pages/OrderDetail.jsx';
import { NavLink, Routes, Route, Navigate, useLocation } from 'react-router-dom';
import Costs from './pages/Costs.jsx';
import Locations from './pages/Locations.jsx';
import Stages from './pages/Stages.jsx';
export default function App() {
  const {
    pathname
  } = useLocation();
  useEffect(() => {
    window.scrollTo({
      top: 0,
      left: 0
    });
  }, [pathname]);
  return <><aside><div className="brand-mark" aria-hidden="true">C</div><h1>CotaLog</h1><p>IDE de Organização e Cotação de Fretes</p><nav>{[['pedidos', 'Pedidos'], ['base-de-custos', 'Base de custos'], ['locais', 'Locais'], ['etapas', 'Etapas']].map(([path, label]) => <NavLink key={path} to={'/' + path}>{label}</NavLink>)}</nav><div className="sidebar-note">Ambiente local<br />Dados fictícios de demonstração</div></aside><main><Routes><Route path="/" element={<Navigate to="/pedidos" replace />} /><Route path="/pedidos" element={<Orders />} /><Route path="/pedidos/novo" element={<OrderForm />} /><Route path="/pedidos/:id" element={<OrderDetail />} /><Route path="/pedidos/:id/editar" element={<OrderForm />} /><Route path="/base-de-custos" element={<Costs />} /><Route path="/locais" element={<Locations />} /><Route path="/etapas" element={<Stages />} /><Route path="*" element={<div className="empty"><h2>Página não encontrada</h2><NavLink to="/pedidos">Voltar para pedidos</NavLink></div>} /></Routes><footer>Protótipo acadêmico — UNISAGRADO</footer></main></>;
}
