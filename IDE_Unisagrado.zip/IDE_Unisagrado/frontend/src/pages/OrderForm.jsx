import { useEffect, useState } from 'react';
import { Link, useNavigate, useParams } from 'react-router-dom';
import { api } from '../api.js';
import { decimal, parseNumber } from '../format.js';
import { useData, useAction, PageState, Heading, Notice, Field } from '../components/common.jsx';
export default function OrderForm() {
  const {
    id
  } = useParams();
  const navigate = useNavigate();
  const state = useData(['locations', 'orders', ...(id ? ['orders/' + id] : [])]);
  const action = useAction();
  const [value, setValue] = useState({});
  const order = state.data?.['orders/' + id];
  useEffect(() => {
    if (order) setValue({
      requesterSector: order.requesterSector,
      requesterName: order.requesterName,
      originLocationId: order.origin.id,
      destinationLocationId: order.destination.id,
      weightKg: decimal(order.weightKg),
      volumeM3: decimal(order.volumeM3),
      desiredDeadlineDate: order.desiredDeadlineDate,
      notes: order.notes || ''
    });else if (!id) setValue({});
  }, [order, id]);
  if (!state.data || id && !order) return <><Heading title={id ? 'Editar pedido' : 'Novo pedido'} /><PageState state={state} /></>;
  const locked = Boolean(order && !order.stage.isInitial);
  const locations = state.data.locations;
  const sectors = [...new Set(state.data.orders.map(o => o.requesterSector))];
  if (!sectors.length) sectors.push('Comercial', 'Compras', 'Financeiro', 'Produção', 'Atendimento');
  const fields = [['requesterSector', 'Setor solicitante', 'text'], ['requesterName', 'Nome do solicitante', 'text'], ['originLocationId', 'Origem', 'select'], ['destinationLocationId', 'Destino', 'select'], ['weightKg', 'Peso (kg)', 'decimal'], ['volumeM3', 'Volume (m³, opcional)', 'decimal'], ['desiredDeadlineDate', 'Prazo desejado', 'date'], ['notes', 'Observações (opcional)', 'textarea']];
  const update = (name, text) => setValue(v => ({
    ...v,
    [name]: text
  }));
  async function submit(e) {
    e.preventDefault();
    await action.run(async () => {
      const body = {
        ...value,
        originLocationId: parseNumber(value.originLocationId) ?? null,
        destinationLocationId: parseNumber(value.destinationLocationId) ?? null,
        weightKg: parseNumber(value.weightKg) ?? null,
        volumeM3: value.volumeM3 === '' || value.volumeM3 == null ? null : parseNumber(value.volumeM3),
        notes: value.notes || null
      };
      const result = await api('orders' + (id ? '/' + id : ''), {
        method: id ? 'PATCH' : 'POST',
        body
      });
      navigate('/pedidos/' + result.id);
    });
  }
  return <><Heading title={id ? 'Editar ' + order.code : 'Novo pedido'} description="Preencha as informações necessárias para comparar o frete." /><Notice message={action.error?.message} onClose={action.close} /><PageState state={state} /><section className="panel order-form"><p className="muted">Campos com * são obrigatórios.</p>{!locations.length && <p className="help">Cadastre locais de origem e destino na tela Locais antes de criar um pedido.</p>}<form onSubmit={submit} noValidate><div className="form-grid">{fields.map(([name, label, type]) => {
            const disabled = locked && ['weightKg', 'originLocationId', 'destinationLocationId'].includes(name);
            const error = action.error?.fields?.[name];
            const props = {
              value: value[name] ?? '',
              onChange: e => update(name, e.target.value),
              disabled,
              'aria-invalid': Boolean(error),
              'aria-required': !['volumeM3', 'notes'].includes(name)
            };
            return <Field key={name} label={label} name={name} required={!['volumeM3', 'notes'].includes(name)} error={error} hint={disabled ? 'Disponível apenas na etapa inicial' : undefined}>{inputId => type === 'select' ? <select id={inputId} {...props} aria-describedby={error ? inputId + '-error' : disabled ? inputId + '-hint' : undefined}><option value="">Selecione…</option>{locations.map(l => <option key={l.id} value={l.id}>{l.name} — {l.uf}</option>)}</select> : type === 'textarea' ? <textarea id={inputId} {...props} maxLength={500} /> : <input id={inputId} {...props} type={type === 'decimal' ? 'text' : type} inputMode={type === 'decimal' ? 'decimal' : undefined} list={name === 'requesterSector' ? 'sectors' : undefined} aria-describedby={error ? inputId + '-error' : disabled ? inputId + '-hint' : undefined} />}</Field>;
          })}</div><datalist id="sectors">{sectors.map(s => <option key={s} value={s} />)}</datalist><div className="actions"><button className="primary" disabled={action.busy}>{action.busy ? 'Salvando…' : 'Salvar'}</button><Link className="button" to={id ? '/pedidos/' + id : '/pedidos'}>Cancelar</Link></div></form></section></>;
}
