import { Link, useNavigate, useParams } from 'react-router-dom';
import { api } from '../api.js';
import { date, money, weight } from '../format.js';
import { useData, useAction, PageState, Heading, Notice, Field } from '../components/common.jsx';
export default function OrderDetail() {
  const {
    id
  } = useParams();
  const navigate = useNavigate();
  const state = useData(['orders/' + id, 'stages', 'carriers']);
  const action = useAction();
  const order = state.data?.['orders/' + id];
  if (!order) return <><Heading title="Detalhe do pedido" /><PageState state={state} /></>;
  const locked = !order.stage.isInitial;
  const quotes = order.quotes;
  const active = state.data.carriers.some(c => c.active);
  const mutate = (path, method = 'POST', body) => action.run(async () => {
    await api('orders/' + id + path, {
      method,
      body
    });
    await state.reload();
  });
  async function remove() {
    if (window.confirm('Tem certeza que deseja excluir ' + order.code + '?')) await action.run(async () => {
      await api('orders/' + id, {
        method: 'DELETE'
      });
      navigate('/pedidos');
    });
  }
  function select(quote) {
    if (!quote.meetsDeadline && !window.confirm('Esta opção não atende ao prazo desejado. Selecionar mesmo assim?')) return;
    mutate('/quotes/' + quote.id + '/select');
  }
  return <><Heading title={order.code} description={'Solicitação de ' + order.requesterSector}><Link className="button" to="/pedidos">Voltar ao quadro</Link><Link className="button primary" to={'/pedidos/' + id + '/editar'}>Editar</Link><button className="danger" onClick={remove} disabled={action.busy}>Excluir</button></Heading><Notice message={action.error?.message} onClose={action.close} /><PageState state={state} /><section className="panel"><h3>Dados do pedido</h3><dl className="order-data">{[['Setor solicitante', order.requesterSector], ['Solicitante', order.requesterName], ['Origem', order.origin.name + ' — ' + order.origin.uf], ['Destino', order.destination.name + ' — ' + order.destination.uf], ['Região de destino', order.destination.regionName], ['Peso', weight(order.weightKg) + ' kg'], ['Volume', order.volumeM3 == null ? 'Não informado' : weight(order.volumeM3) + ' m³'], ['Prazo desejado', date(order.desiredDeadlineDate)]].map(([label, text]) => <div key={label}><dt>{label}</dt><dd>{text}</dd></div>)}</dl>{order.notes && <div className="notes"><h4>Observações</h4><p>{order.notes}</p></div>}<div className="stage-control"><Field label="Etapa">{inputId => <select id={inputId} value={order.stage.id} disabled={action.busy} onChange={e => mutate('/stage', 'POST', {
            stageId: Number(e.target.value)
          })}>{state.data.stages.map(s => <option key={s.id} value={s.id}>{s.name}</option>)}</select>}</Field></div></section><section className="panel"><div className="section-heading"><div><h3>Cotação de frete</h3><p className="muted">Compare valor e prazo para escolher a transportadora.</p></div><div><button className="primary" onClick={() => mutate('/quotes')} disabled={locked || action.busy} title={locked ? 'Disponível apenas na etapa inicial' : undefined}>{quotes.length ? 'Recotar' : 'Cotar frete'}</button>{locked && <small className="lock-hint">Disponível apenas na etapa inicial</small>}</div></div>{quotes.length > 0 && !quotes.some(q => q.available && q.meetsDeadline) && <Notice tone="warning" message="Nenhuma transportadora atende ao prazo desejado." />}{!active && <p className="empty">Nenhuma transportadora ativa cadastrada. Cadastre em <Link to="/base-de-custos">Base de custos</Link>.</p>}{quotes.length > 0 ? <div className="table-wrap"><table className="quotes-table"><thead><tr>{['Transportadora', 'Valor', 'Prazo (dias)', 'Entrega estimada', 'Prazo', 'Ação'].map(t => <th key={t}>{t}</th>)}</tr></thead><tbody>{quotes.map(q => <tr key={q.id} className={!q.available ? 'unavailable' : q.isSelected ? 'selected-quote' : ''}><td><strong>{q.carrierName}</strong><div>{q.badges.map(b => <span key={b} className={'badge ' + (b === 'fastest' ? 'blue' : '')}>{b === 'cheapest' ? 'Mais barata' : 'Mais rápida'}</span>)}</div></td><td className="price">{q.available ? money(q.priceCents) : '—'}</td><td>{q.available ? q.leadTimeDays : '—'}</td><td>{date(q.estimatedDeliveryDate)}</td><td>{!q.available ? <span>{q.unavailableReason}</span> : <span className={q.meetsDeadline ? 'positive' : 'warning-text'}>{q.meetsDeadline ? 'No prazo' : 'Fora do prazo'}</span>}</td><td>{q.available && (q.isSelected ? <div className="selection-actions"><strong className="positive">Selecionada</strong><button disabled={locked || action.busy} title={locked ? 'Disponível apenas na etapa inicial' : undefined} onClick={() => mutate('/selection', 'DELETE')}>Remover seleção</button></div> : <button onClick={() => select(q)} disabled={action.busy}>Selecionar</button>)}</td></tr>)}</tbody></table></div> : active && <p className="empty">Nenhuma cotação gerada. Clique em Cotar frete para comparar as transportadoras.</p>}</section></>;
}
