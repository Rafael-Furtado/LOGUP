import { useState } from 'react';
import { api } from '../api.js';
import { money, weight } from '../format.js';
import { useData, useAction, PageState, Heading, Notice, NameList, ResourceForm } from '../components/common.jsx';
export default function Costs() {
  const state = useData(['carriers', 'regions', 'rate-rules']);
  const action = useAction();
  const [selected, setSelected] = useState(null),
    [region, setRegion] = useState(''),
    [editing, setEditing] = useState(null);
  if (!state.data) return <><Heading title="Base de custos" description="Configure as transportadoras e suas tabelas de frete." /><PageState state={state} /></>;
  const {
    carriers,
    regions
  } = state.data;
  const carrier = carriers.find(c => c.id === selected);
  const rules = state.data['rate-rules'].filter(r => r.carrierId === selected && (!region || r.regionId === Number(region)));
  const fields = [{
    name: 'regionId',
    label: 'Região de destino',
    type: 'select',
    options: regions
  }, {
    name: 'minWeightKg',
    label: 'De (kg, exclusivo)',
    type: 'number'
  }, {
    name: 'maxWeightKg',
    label: 'Até (kg, inclusivo)',
    type: 'number'
  }, {
    name: 'pricePerKgCents',
    label: 'Preço por kg (R$)',
    type: 'money'
  }, {
    name: 'minChargeCents',
    label: 'Mínimo (R$)',
    type: 'money'
  }, {
    name: 'fixedFeeCents',
    label: 'Taxa fixa (R$)',
    type: 'money'
  }, {
    name: 'leadTimeDays',
    label: 'Prazo (dias corridos)',
    type: 'number'
  }];
  async function save(body, reset) {
    await action.run(async () => {
      await api('rate-rules' + (editing ? '/' + editing.id : ''), {
        method: editing ? 'PATCH' : 'POST',
        body: {
          ...body,
          carrierId: selected
        }
      });
      setEditing(null);
      reset();
      await state.reload();
    });
  }
  async function remove(rule) {
    if (window.confirm('Tem certeza que deseja excluir esta regra de custo?')) await action.run(async () => {
      await api('rate-rules/' + rule.id, {
        method: 'DELETE'
      });
      if (editing?.id === rule.id) setEditing(null);
      await state.reload();
    });
  }
  return <><Heading title="Base de custos" description="Configure preços por região e faixa de peso, sem escrever código." /><PageState state={state} /><NameList title="Transportadoras" resource="carriers" items={carriers} active selectedId={selected} onSelect={id => {
      setSelected(id);
      setEditing(null);
      action.clear();
    }} onChange={state.reload} />{carrier ? <section className="panel"><div className="section-heading"><div><span className="eyebrow">REGRAS DE CUSTO</span><h3>{carrier.name}</h3></div><label>Filtrar por região <select value={region} onChange={e => setRegion(e.target.value)}><option value="">Todas as regiões</option>{regions.map(r => <option key={r.id} value={r.id}>{r.name}</option>)}</select></label></div><Notice message={action.error?.message} onClose={action.close} /><div className="table-wrap"><table><thead><tr>{['Região', 'De (kg, exclusivo)', 'Até (kg)', 'R$/kg', 'Mínimo (R$)', 'Taxa fixa (R$)', 'Prazo (dias)', 'Ações'].map(t => <th key={t}>{t}</th>)}</tr></thead><tbody>{rules.map(r => <tr key={r.id}><td>{r.regionName}</td><td>{weight(r.minWeightKg)}</td><td>{weight(r.maxWeightKg)}</td><td>{money(r.pricePerKgCents)}</td><td>{money(r.minChargeCents)}</td><td>{money(r.fixedFeeCents)}</td><td>{r.leadTimeDays}</td><td><div className="actions"><button onClick={() => {
                    setEditing(r);
                    action.clear();
                  }}>Editar</button><button className="danger" onClick={() => remove(r)}>Excluir</button></div></td></tr>)}</tbody></table></div>{rules.length === 0 && <p className="empty">Nenhuma regra nesta seleção. Cadastre uma faixa de peso abaixo.</p>}<div className="form-section"><h4>{editing ? 'Editar regra' : 'Nova regra'}</h4><p className="muted">O peso mínimo é exclusivo; o máximo está incluído na faixa. Os valores são em reais.</p>{regions.length === 0 && <p>Cadastre uma região em Locais para adicionar regras.</p>}<ResourceForm key={selected + '-' + (editing?.id || 'new')} fields={fields} initial={editing} onSave={save} onCancel={editing ? () => {
          setEditing(null);
          action.clear();
        } : undefined} busy={action.busy} errors={action.error?.fields} /></div></section> : <section className="panel empty">Selecione uma transportadora para consultar e configurar suas regras de custo.</section>}</>;
}
