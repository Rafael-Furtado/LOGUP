import { useState } from 'react';
import { api } from '../api.js';
import { useData, useAction, PageState, Heading, Notice, Field } from '../components/common.jsx';
export default function Stages() {
  const state = useData(['stages']);
  const action = useAction();
  const [name, setName] = useState(''),
    [editing, setEditing] = useState(null),
    [draft, setDraft] = useState('');
  if (!state.data) return <><Heading title="Etapas" /><PageState state={state} /></>;
  const stages = state.data.stages;
  const change = (id, body) => action.run(async () => {
    await api('stages/' + id, {
      method: 'PATCH',
      body
    });
    await state.reload();
  });
  async function save(e, id) {
    e.preventDefault();
    await action.run(async () => {
      await api('stages' + (id ? '/' + id : ''), {
        method: id ? 'PATCH' : 'POST',
        body: {
          name: id ? draft : name
        }
      });
      setName('');
      setEditing(null);
      await state.reload();
    });
  }
  async function move(index, direction) {
    const ids = stages.map(s => s.id);
    [ids[index], ids[index + direction]] = [ids[index + direction], ids[index]];
    await action.run(async () => {
      await api('stages/order', {
        method: 'PUT',
        body: {
          ids
        }
      });
      await state.reload();
    });
  }
  async function remove(stage) {
    if (window.confirm('Tem certeza que deseja excluir ' + stage.name + '?')) await action.run(async () => {
      await api('stages/' + stage.id, {
        method: 'DELETE'
      });
      await state.reload();
    });
  }
  return <><Heading title="Etapas" description="Configure a sequência do quadro de pedidos." /><p className="help">Todo pedido novo entra na etapa inicial. Para avançar, é preciso selecionar uma cotação.</p><PageState state={state} /><Notice message={action.error?.message} onClose={action.close} /><section className="panel"><div className="table-wrap"><table><thead><tr><th>Ordem</th><th>Nome</th><th>Inicial</th><th>Final</th><th>Ações</th></tr></thead><tbody>{stages.map((stage, index) => <tr key={stage.id}><td><div className="actions"><button aria-label={'Subir ' + stage.name} disabled={index === 0 || action.busy} onClick={() => move(index, -1)}>↑</button><button aria-label={'Descer ' + stage.name} disabled={index === stages.length - 1 || action.busy} onClick={() => move(index, 1)}>↓</button></div></td><td>{editing === stage.id ? <form className="inline-form" onSubmit={e => save(e, stage.id)} noValidate><Field label="Nome" error={action.error?.fields?.name}>{id => <input id={id} value={draft} onChange={e => setDraft(e.target.value)} />}</Field><button disabled={action.busy}>Salvar</button><button type="button" onClick={() => {
                    setEditing(null);
                    action.clear();
                  }}>Cancelar</button></form> : <strong>{stage.name}</strong>}</td><td><label className="radio-label"><input type="radio" name="initial" checked={stage.isInitial} onChange={() => change(stage.id, {
                    isInitial: true
                  })} disabled={action.busy} />Inicial</label></td><td><label className="radio-label"><input type="radio" name="final" checked={stage.isFinal} onChange={() => change(stage.id, {
                    isFinal: true
                  })} disabled={action.busy} />Final</label></td><td><div className="actions"><button onClick={() => {
                    setEditing(stage.id);
                    setDraft(stage.name);
                    action.clear();
                  }}>Renomear</button><button className="danger" onClick={() => remove(stage)}>Excluir</button></div></td></tr>)}</tbody></table></div>{stages.length === 0 && <p className="empty">Nenhuma etapa cadastrada.</p>}<form className="inline-form create-form" onSubmit={e => save(e)} noValidate><Field label="Nova etapa" required error={!editing ? action.error?.fields?.name : null}>{id => <input id={id} value={name} onChange={e => setName(e.target.value)} />}</Field><button className="primary" disabled={action.busy}>Adicionar</button></form></section></>;
}
