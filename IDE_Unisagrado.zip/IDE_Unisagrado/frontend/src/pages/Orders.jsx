import { useState, useEffect } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { api } from '../api.js';
import { date, weight, money, todayISO } from '../format.js';
import { useData, useAction, PageState, Heading, Notice, Field } from '../components/common.jsx';
export default function Orders() {
  const [search, setSearch] = useState(''),
    [query, setQuery] = useState('');
  useEffect(() => {
    const timer = setTimeout(() => setQuery(search), 300);
    return () => clearTimeout(timer);
  }, [search]);
  const path = 'orders?search=' + encodeURIComponent(query);
  const state = useData(['stages', path]);
  const action = useAction();
  const navigate = useNavigate();
  const [dragged, setDragged] = useState(null);
  const orders = state.data?.[path] || [];
  const stages = state.data?.stages || [];
  async function move(id, stageId) {
    await action.run(async () => {
      await api('orders/' + id + '/stage', {
        method: 'POST',
        body: {
          stageId
        }
      });
      await state.reload();
    });
  }
  function drop(e, stageId) {
    e.preventDefault();
    const id = Number(e.dataTransfer.getData('text/plain'));
    if (orders.some(o => o.id === id)) move(id, stageId);
    setDragged(null);
  }
  return <><Heading title="Pedidos" description="Organize solicitações, compare fretes e acompanhe cada etapa."><a className="button" href="/api/orders/export.csv" download>Exportar CSV</a><Link className="button success" to="/pedidos/novo">Novo pedido</Link></Heading><div className="board-toolbar"><Field label="Buscar" hint="Código, solicitante, setor, local ou transportadora.">{id => <input id={id} type="search" value={search} placeholder="Buscar pedidos…" onChange={e => setSearch(e.target.value)} />}</Field><span className="muted">{orders.length} {orders.length === 1 ? 'pedido' : 'pedidos'}{state.loading ? ' · Carregando…' : ''}</span></div><Notice message={action.error?.message} onClose={action.close} /><PageState state={state} />{state.data && <><div className="board-scroll"><div className="board" style={{
          '--columns': stages.length
        }}>{stages.map(stage => {
            const rows = orders.filter(o => o.stage.id === stage.id);
            return <section key={stage.id} className={'board-column ' + (dragged ? 'drop-ready' : '')} aria-label={stage.name} onDragOver={e => {
              e.preventDefault();
              e.dataTransfer.dropEffect = 'move';
            }} onDrop={e => drop(e, stage.id)}><h3><span>{stage.name}</span><span className="count">{rows.length}</span></h3><div className="column-cards">{rows.map(order => {
                  const overdue = order.desiredDeadlineDate < todayISO() && !order.stage.isFinal;
                  return <article key={order.id} className={'order-card ' + (overdue ? 'overdue ' : '') + (dragged === order.id ? 'dragging' : '')} draggable tabIndex={0} aria-label={order.code} onDragStart={e => {
                    e.dataTransfer.setData('text/plain', String(order.id));
                    e.dataTransfer.effectAllowed = 'move';
                    setDragged(order.id);
                  }} onDragEnd={() => setDragged(null)} onClick={e => {
                    if (!e.target.closest('select,button,a,label')) navigate('/pedidos/' + order.id);
                  }} onKeyDown={e => {
                    if (e.key === 'Enter' && e.target === e.currentTarget) navigate('/pedidos/' + order.id);
                  }}><div className="card-top"><Link to={'/pedidos/' + order.id}>{order.code}</Link>{overdue && <span className="overdue-label">Prazo vencido</span>}</div><h4>{order.requesterName}</h4><p className="card-sector">{order.requesterSector}</p><p className="card-route">{order.origin.name}<span aria-hidden="true"> → </span>{order.destination.name}</p><div className="card-meta"><span>{weight(order.weightKg)} kg</span><span>Até {date(order.desiredDeadlineDate)}</span></div><p className={'quote-chip ' + (order.selectedQuote ? 'has-quote' : '')}>{order.selectedQuote ? <>{order.selectedQuote.carrierName}<strong>{money(order.selectedQuote.priceCents)}</strong></> : 'Sem cotação'}</p><label className="move-label">Mover para…<select value={order.stage.id} aria-label={'Mover ' + order.code + ' para'} disabled={action.busy} onClick={e => e.stopPropagation()} onChange={e => move(order.id, Number(e.target.value))}>{stages.map(s => <option key={s.id} value={s.id}>{s.name}</option>)}</select></label></article>;
                })}{rows.length === 0 && <p className="column-empty">Nenhum pedido nesta etapa.</p>}</div></section>;
          })}</div></div>{orders.length === 0 && !state.loading && <p className="empty">{query ? 'Nenhum pedido corresponde à busca. Tente outro termo.' : 'Nenhum pedido cadastrado. Clique em Novo pedido para começar.'}</p>}</>}</>;
}
