import { useState } from 'react';
import { api } from '../api.js';
import { useData, useAction, PageState, Heading, Notice, NameList, ResourceForm } from '../components/common.jsx';
const ufs = ['AC', 'AL', 'AP', 'AM', 'BA', 'CE', 'DF', 'ES', 'GO', 'MA', 'MT', 'MS', 'MG', 'PA', 'PB', 'PR', 'PE', 'PI', 'RJ', 'RN', 'RS', 'RO', 'RR', 'SC', 'SP', 'SE', 'TO'];
export default function Locations() {
  const state = useData(['regions', 'locations']);
  const action = useAction();
  const [editing, setEditing] = useState(null);
  if (!state.data) return <><Heading title="Locais" description="Organize regiões, origens e destinos." /><PageState state={state} /></>;
  const {
    regions,
    locations
  } = state.data;
  const fields = [{
    name: 'name',
    label: 'Nome do local'
  }, {
    name: 'uf',
    label: 'UF',
    type: 'uf',
    options: ufs
  }, {
    name: 'regionId',
    label: 'Região',
    type: 'select',
    options: regions
  }];
  async function save(body, reset) {
    await action.run(async () => {
      await api('locations' + (editing ? '/' + editing.id : ''), {
        method: editing ? 'PATCH' : 'POST',
        body
      });
      setEditing(null);
      reset();
      await state.reload();
    });
  }
  async function remove(location) {
    if (window.confirm('Tem certeza que deseja excluir ' + location.name + '?')) await action.run(async () => {
      await api('locations/' + location.id, {
        method: 'DELETE'
      });
      if (editing?.id === location.id) setEditing(null);
      await state.reload();
    });
  }
  return <><Heading title="Locais" description="Organize regiões e os locais usados como origem e destino dos pedidos." /><PageState state={state} /><NameList title="Regiões" resource="regions" items={regions} onChange={state.reload} /><section className="panel"><h3>Locais</h3><Notice message={action.error?.message} onClose={action.close} />{locations.length ? <div className="table-wrap"><table><thead><tr><th>Nome</th><th>UF</th><th>Região</th><th>Ações</th></tr></thead><tbody>{locations.map(location => <tr key={location.id}><td>{location.name}</td><td>{location.uf}</td><td>{location.regionName}</td><td><div className="actions"><button onClick={() => {
                    setEditing(location);
                    action.clear();
                  }}>Editar</button><button className="danger" onClick={() => remove(location)}>Excluir</button></div></td></tr>)}</tbody></table></div> : <p className="empty">Nenhum local cadastrado. Adicione uma origem ou um destino abaixo.</p>}<div className="form-section"><h4>{editing ? 'Editar local' : 'Novo local'}</h4><ResourceForm fields={fields} initial={editing} onSave={save} onCancel={editing ? () => {
          setEditing(null);
          action.clear();
        } : undefined} busy={action.busy} errors={action.error?.fields} /></div></section></>;
}
