export async function api(path, options = {}) {
  let response;
  try {
    response = await fetch('/api/' + path, {
      ...options,
      headers: {
        'Content-Type': 'application/json',
        ...options.headers
      },
      ...(options.body !== undefined ? {
        body: JSON.stringify(options.body)
      } : {})
    });
  } catch {
    throw new Error('Não foi possível comunicar com o servidor.');
  }
  if (!response.ok) {
    const payload = await response.json().catch(() => ({
      error: {
        message: 'Não foi possível comunicar com o servidor.'
      }
    }));
    throw Object.assign(new Error(payload.error?.message || 'Não foi possível concluir a operação.'), {
      fields: payload.error?.fields || {},
      status: response.status
    });
  }
  return response.status === 204 ? null : response.json();
}
