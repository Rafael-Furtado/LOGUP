const currency = new Intl.NumberFormat('pt-BR', {
  style: 'currency',
  currency: 'BRL'
});
export const money = cents => currency.format(cents / 100);
export const date = value => value ? value.slice(0, 10).split('-').reverse().join('/') : '—';
export const weight = value => new Intl.NumberFormat('pt-BR', {
  maximumFractionDigits: 3
}).format(value);
export const decimal = value => value == null ? '' : String(value).replace('.', ',');
export const moneyInput = cents => cents == null ? '' : (cents / 100).toFixed(2).replace('.', ',');
export function parseNumber(value) {
  if (value === '' || value == null) return undefined;
  const n = Number(String(value).replace(',', '.'));
  return Number.isFinite(n) ? n : value;
}
export function todayISO() {
  const parts = new Intl.DateTimeFormat('en-CA', {
    timeZone: 'America/Sao_Paulo',
    year: 'numeric',
    month: '2-digit',
    day: '2-digit'
  }).formatToParts(new Date());
  return ['year', 'month', 'day'].map(type => parts.find(part => part.type === type).value).join('-');
}
export function toCents(value) {
  const number = parseNumber(value);
  return typeof number === 'number' ? Math.round(number * 100) : number;
}
