import { useState, useEffect, useCallback, useId } from 'react';
import { api } from '../api.js';
import { decimal, moneyInput, parseNumber, toCents } from '../format.js';
export function useData(resources) {
  const key = resources.join('|');
  const [data, setData] = useState(null),
    [loading, setLoading] = useState(true),
    [error, setError] = useState(null);
  const reload = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      const paths = key.split('|');
      const values = await Promise.all(paths.map(path => api(path)));
      const result = Object.fromEntries(paths.map((path, i) => [path, values[i]]));
      setData(result);
      return result;
    } catch (e) {
      setError(e.message);
      return null;
    } finally {
      setLoading(false);
    }
  }, [key]);
  useEffect(() => {
    reload();
  }, [reload]);
  return {
    data,
    loading,
    error,
    reload
  };
}
export function useAction() {
  const [error, setError] = useState(null),
    [busy, setBusy] = useState(false);
  const run = async task => {
    setError(null);
    setBusy(true);
    try {
      await task();
      return true;
    } catch (e) {
      setError(e);
      return false;
    } finally {
      setBusy(false);
    }
  };
  return {
    error,
    busy,
    run,
    clear: () => setError(null),
    close: () => setError(e => e ? {
      ...e,
      message: ''
    } : null)
  };
}
export function Notice({
  message,
  onClose,
  tone = 'error'
}) {
  useEffect(() => {
    if (message && onClose) {
      const timer = setTimeout(onClose, 6000);
      return () => clearTimeout(timer);
    }
  }, [message, onClose]);
  return message ? <div className={'notice ' + tone} role="alert"><span>{message}</span>{onClose && <button type="button" onClick={onClose}>Fechar</button>}</div> : null;
}
export function PageState({
  state
}) {
  if (state.error) return <div className="empty"><p role="alert">{state.error}</p><button onClick={state.reload}>Tentar novamente</button></div>;
  if (!state.data && state.loading) return <p role="status">Carregando…</p>;
  return null;
}
export function Heading({
  title,
  description,
  children
}) {
  return <header className="page-heading"><div><span className="eyebrow">AMBIENTE DE LOGÍSTICA</span><h2>{title}</h2>{description && <p>{description}</p>}</div><div className="actions">{children}</div></header>;
}
export function Field({
  label,
  name,
  error,
  children,
  required,
  hint
}) {
  const id = useId();
  return <div className="field"><label htmlFor={id}>{label}{required ? ' *' : ''}</label>{children(id)}{hint && <small id={id + '-hint'}>{hint}</small>}{error && <small id={id + '-error'} className="field-error">{error}</small>}</div>;
}
export function ResourceForm({
  fields,
  initial,
  onSave,
  onCancel,
  busy,
  errors = {},
  submitLabel = 'Salvar'
}) {
  const [value, setValue] = useState({});
  useEffect(() => {
    setValue(Object.fromEntries(fields.map(f => [f.name, initial?.[f.name] == null ? '' : f.type === 'money' ? moneyInput(initial[f.name]) : f.type === 'number' ? decimal(initial[f.name]) : initial[f.name]])));
  }, [initial]);
  const submit = e => {
    e.preventDefault();
    const body = Object.fromEntries(fields.map(f => [f.name, f.type === 'money' ? toCents(value[f.name]) : f.type === 'number' || f.type === 'select' ? parseNumber(value[f.name]) : value[f.name] ?? '']));
    onSave(body, () => setValue({}));
  };
  return <form onSubmit={submit} noValidate><div className="form-grid">{fields.map(f => <Field key={f.name} label={f.label} name={f.name} required={f.required !== false} error={errors[f.name]} hint={f.hint}>{id => f.type === 'select' ? <select id={id} value={value[f.name] ?? ''} onChange={e => setValue({
          ...value,
          [f.name]: e.target.value
        })} aria-invalid={Boolean(errors[f.name])} aria-describedby={errors[f.name] ? id + '-error' : undefined}><option value="">Selecione…</option>{f.options?.map(o => <option key={o.id} value={o.id}>{o.name}</option>)}</select> : f.type === 'uf' ? <select id={id} value={value[f.name] ?? ''} onChange={e => setValue({
          ...value,
          [f.name]: e.target.value
        })}><option value="">Selecione…</option>{f.options.map(uf => <option key={uf}>{uf}</option>)}</select> : <input id={id} type="text" inputMode={['number', 'money'].includes(f.type) ? 'decimal' : undefined} value={value[f.name] ?? ''} onChange={e => setValue({
          ...value,
          [f.name]: e.target.value
        })} aria-invalid={Boolean(errors[f.name])} aria-describedby={errors[f.name] ? id + '-error' : undefined} />}</Field>)}</div><div className="actions"><button className="primary" disabled={busy}>{busy ? 'Salvando…' : submitLabel}</button>{onCancel && <button type="button" onClick={onCancel}>Cancelar</button>}</div></form>;
}
export function NameList({
  title,
  resource,
  items,
  onChange,
  onSelect,
  selectedId,
  active = false
}) {
  const action = useAction();
  const [editing, setEditing] = useState(null),
    [draft, setDraft] = useState(''),
    [name, setName] = useState('');
  async function save(e, id) {
    e.preventDefault();
    await action.run(async () => {
      await api(resource + (id ? '/' + id : ''), {
        method: id ? 'PATCH' : 'POST',
        body: {
          name: id ? draft : name
        }
      });
      setEditing(null);
      setName('');
      await onChange();
    });
  }
  async function remove(item) {
    if (window.confirm('Tem certeza que deseja excluir ' + item.name + '?')) await action.run(async () => {
      await api(resource + '/' + item.id, {
        method: 'DELETE'
      });
      await onChange();
    });
  }
  return <section className="panel"><h3>{title}</h3><Notice message={action.error?.message} onClose={action.close} />{items.length === 0 ? <p className="empty">Nenhum registro cadastrado. Use o formulário abaixo para começar.</p> : <ul className="record-list">{items.map(item => <li key={item.id} className={selectedId === item.id ? 'selected' : ''}>{editing === item.id ? <form className="inline-form" onSubmit={e => save(e, item.id)} noValidate><Field label="Nome" error={action.error?.fields?.name}>{id => <input id={id} value={draft} onChange={e => setDraft(e.target.value)} />}</Field><button disabled={action.busy}>Salvar</button><button type="button" onClick={() => {
            setEditing(null);
            action.clear();
          }}>Cancelar</button></form> : <><div className="record-name">{onSelect ? <button className="text-button" onClick={() => onSelect(item.id)}>{item.name}</button> : <strong>{item.name}</strong>}{active && <label className="toggle"><input type="checkbox" role="switch" checked={item.active} disabled={action.busy} onChange={e => action.run(async () => {
                await api(resource + '/' + item.id, {
                  method: 'PATCH',
                  body: {
                    active: e.target.checked
                  }
                });
                await onChange();
              })} />Ativa</label>}</div><div className="actions"><button onClick={() => {
              setEditing(item.id);
              setDraft(item.name);
              action.clear();
            }}>Renomear</button><button className="danger" disabled={action.busy} onClick={() => remove(item)}>Excluir</button></div></>}</li>)}</ul>}<form className="inline-form create-form" onSubmit={e => save(e)} noValidate><Field label={resource === 'carriers' ? 'Nova transportadora' : 'Nova região'} required error={!editing ? action.error?.fields?.name : null}>{id => <input id={id} value={name} onChange={e => setName(e.target.value)} />}</Field><button className="primary" disabled={action.busy}>Adicionar</button></form></section>;
}
