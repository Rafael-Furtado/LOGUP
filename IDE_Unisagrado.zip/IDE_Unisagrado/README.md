# CotaLog

Protótipo acadêmico do Bootcamp UNISAGRADO: uma IDE de Organização e Cotação de Fretes. Neste projeto, IDE é um ambiente configurável de domínio: a equipe configura transportadoras, custos, locais e etapas sem escrever código; o sistema valida solicitações e calcula cotações comparáveis.

**Todos os dados de demonstração são fictícios.** O sistema funciona localmente, com um único usuário por vez e sem login.

## Requisitos e instalação

- Node.js 20 ou superior e npm, com acesso à internet para a instalação inicial.
- Validado neste ambiente com Node.js 24.21.0 e npm 11.19.0.
- As portas 3001 e 5173 devem estar disponíveis.

Na raiz do projeto:

```sh
npm install
npm run db:reset
npm start
```

Abra [CotaLog](http://localhost:3001). `npm start` compila o frontend e inicia o backend, que serve o aplicativo completo, inclusive rotas como `/pedidos/1`.

`db:reset` apaga o banco e recria os oito pedidos fictícios e todos os cadastros. **Encerre o servidor com Ctrl+C antes de restaurar o banco**, especialmente no Windows, onde um arquivo SQLite aberto fica bloqueado.

Para desenvolvimento, depois da instalação e do seed:

```sh
npm run dev
```

Abra [Frontend de desenvolvimento](http://localhost:5173). O Vite encaminha `/api` ao backend em `http://localhost:3001`. O backend usa `node --watch`. Se uma pasta sincronizada provocar reinícios ao detectar mudanças em dependências, use `npm start` para a demonstração sem observação de arquivos.

Para encerrar os servidores, pressione Ctrl+C no terminal correspondente.

## Banco de dados

O SQLite fica em `backend/data/cotalog.db`, ignorado pelo Git. `DB_PATH` pode definir outro arquivo; prefira um caminho absoluto. Os testes usam `:memory:`.

Ao iniciar, o servidor cria o schema de forma idempotente e insere as cinco etapas padrão se não houver etapas. Transportadoras, regiões, locais, regras e pedidos de demonstração entram somente por `npm run db:reset`.

As datas de prazo usam `YYYY-MM-DD`; hoje é calculado no fuso `America/Sao_Paulo`. Os prazos do seed são relativos à data de sua execução. Os timestamps da API são ISO 8601 UTC. Valores monetários da API e do banco são inteiros em centavos; os formulários aceitam valores como `72,50` reais.

## Funcionalidades

- Transportadoras com ativação, renomeação e exclusão condicionada ao uso.
- Regras por transportadora, região de destino e faixa de peso, com bloqueio de sobreposição.
- Regiões, locais e etapas configuráveis, incluindo ordem, inicial e final.
- Pedidos com campos obrigatórios, validação no backend e mensagens abaixo dos campos.
- Quadro por etapas com busca de 300 ms, movimentação por arrastar ou select e destaque de prazo vencido.
- Cotação automática, comparativo, selos de menor valor e menor prazo e confirmação para escolha fora do prazo desejado.
- Exportação CSV em UTF-8 com BOM, `;`, decimais com vírgula e proteção contra fórmulas.

O pedido só sai da etapa inicial após selecionar uma cotação. Fora dela, peso, origem, destino, recotação e remoção de seleção ficam bloqueados. Voltar à inicial é permitido. Alterar peso, origem ou destino na inicial elimina as cotações anteriores.

## Regra de cotação

A faixa é `(mínimo, máximo]`. Só a região de destino participa do cálculo; a origem e o volume são informativos. O valor é o maior entre o mínimo da regra e o custo por peso, somado à taxa fixa. O cálculo arredonda centavos usando gramas e aritmética inteira. A entrega soma dias corridos à data da cotação.

Consulte [fórmula e exemplos E1–E6](docs/REGRA-DE-COTACAO.md) e [decisões registradas](docs/DECISOES.md).

## Testes e build

```sh
npm test
npm run build
```

O Vitest e o Supertest exercitam o backend com SQLite em memória e relógio fixo em `2026-11-10`: exemplos oficiais, limites de faixa, validações, fluxo, etapas, exclusões, busca, CSV e seed. Não há testes automatizados do frontend; o roteiro da seção 14 de [AGENTS.md](AGENTS.md) é executado no navegador.

Verificação de entrega: os passos 1–10 foram conferidos no navegador, incluindo arrastar e soltar, confirmação de opção fora do prazo, bloqueios R1/R2 e erros de campo. A validação final também cobre CSV, largura de 360 px e execução pelo servidor de demonstração.

## Estrutura

```text
backend/
  src/
    app.js, server.js     aplicação Express e inicialização
    db/                   conexão, schema, inicialização e seed
    domain/               cálculo puro, datas, dinheiro e leitura de pedidos
    routes/               cadastros, validações, etapas e pedidos
    middleware/           formato centralizado de erros
    csv.js                exportação com escape e BOM
  tests/                  testes unitários e de integração
frontend/
  src/
    pages/                cadastros, quadro, formulário e detalhe
    components/           campos, avisos e estados comuns
    api.js, format.js     acesso à API e formatação pt-BR
    styles.css            CSS puro e responsividade
  vite.config.js          proxy de desenvolvimento
  dist/                   build gerado, fora do Git
docs/                     regra de cotação e decisões
AGENTS.md                 especificação completa
package-lock.json         versões instaladas
```

## Limitações do protótipo

Sem login ou permissões, multiusuário, notificações, e-mail/WhatsApp, APIs de transportadoras, impostos, cubagem, auditoria de movimentações, anexos, relatórios ou gráficos. Não há internacionalização, deploy em nuvem, Docker, aplicativo mobile nativo ou tema escuro. Não utiliza logotipo nem dados reais da BandUp.
