import { vi } from 'vitest';
vi.setConfig({
  testTimeout: 15000
});
import { beforeEach, afterEach, it, expect } from 'vitest';
import request from 'supertest';
import { connect } from '../src/db/connection.js';
import { seed } from '../src/db/seed.js';
import { createApp } from '../src/app.js';
import { escapeCell, columns } from '../src/csv.js';
let db, api;
const data = {
  requesterSector: 'Comercial',
  requesterName: 'Pessoa fictícia',
  originLocationId: 1,
  destinationLocationId: 3,
  weightKg: 20,
  desiredDeadlineDate: '2026-11-17'
};
beforeEach(() => {
  db = connect(':memory:');
  seed(db, '2026-11-10');
  api = request(createApp(db, {
    today: () => '2026-11-10'
  }));
});
afterEach(() => db.close());
it.each(['requesterSector', 'requesterName', 'originLocationId', 'destinationLocationId', 'weightKg', 'desiredDeadlineDate'])('exige %s', async field => {
  const body = {
    ...data
  };
  delete body[field];
  await api.post('/api/orders').send(body).expect(400).expect(r => expect(r.body.error.fields[field]).toBe('Campo obrigatório.'));
});
it.each([['destinationLocationId', 1, 'Origem e destino devem ser diferentes.'], ['weightKg', 0, 'Informe um peso maior que zero.'], ['weightKg', -1, 'Informe um peso maior que zero.'], ['weightKg', 1.2345, 'Informe no máximo 3 casas decimais.'], ['desiredDeadlineDate', '2026-11-09', 'O prazo desejado não pode ser anterior a hoje.'], ['desiredDeadlineDate', '2026-02-30', 'Informe uma data válida.'], ['originLocationId', 999, 'Selecione um registro existente.']])('valida %s = %s', async (field, value, message) => {
  await api.post('/api/orders').send({
    ...data,
    [field]: value
  }).expect(400).expect(r => expect(r.body.error.fields[field]).toBe(message));
});
it('cria, busca e edita pedido na etapa inicial; demais campos podem mudar fora dela', async () => {
  const result = await api.post('/api/orders').send(data).expect(201);
  expect(result.body.stage.isInitial).toBe(true);
  expect(result.body.code).toBe('PED-0009');
  await api.patch('/api/orders/' + result.body.id).send({
    notes: 'Observação fictícia',
    volumeM3: 1.234
  }).expect(200);
  await api.patch('/api/orders/3').send({
    requesterName: 'Nome editado',
    desiredDeadlineDate: '2026-01-01'
  }).expect(200);
  await api.get('/api/orders/999').expect(404);
  await api.delete('/api/orders/' + result.body.id).expect(204);
  await api.get('/api/orders/' + result.body.id).expect(404);
});
it('R1: exige seleção para avançar; permite ficar na inicial e voltar sem apagar', async () => {
  await api.post('/api/orders/1/stage').send({
    stageId: 2
  }).expect(409).expect(r => expect(r.body.error.message).toBe('Selecione uma cotação antes de avançar o pedido.'));
  await api.post('/api/orders/1/stage').send({
    stageId: 1
  }).expect(200);
  const result = await api.post('/api/orders/1/quotes').expect(201);
  const selected = await api.post(`/api/orders/1/quotes/${result.body.quotes[0].id}/select`).expect(200);
  expect(selected.body.selectedQuote.carrierName).toBe('Gama Cargas');
  await api.post('/api/orders/1/stage').send({
    stageId: 2
  }).expect(200);
  await api.post('/api/orders/1/stage').send({
    stageId: 1
  }).expect(200).expect(r => expect(r.body.selectedQuote).toBeTruthy());
});
it('R2: bloqueia peso, origem, destino, recotação e remoção fora da inicial', async () => {
  for (const patch of [{
    weightKg: 301
  }, {
    originLocationId: 2
  }, {
    destinationLocationId: 3
  }]) await api.patch('/api/orders/3').send(patch).expect(409).expect(r => expect(r.body.error.message).toContain('Só é possível alterar'));
  await api.post('/api/orders/3/quotes').expect(409);
  await api.delete('/api/orders/3/selection').expect(409);
});
it.each([{
  weightKg: 21
}, {
  originLocationId: 2
}, {
  destinationLocationId: 4
}])('alterar campo sensível %j apaga todas as cotações', async patch => {
  const result = await api.post('/api/orders/1/quotes').expect(201);
  await api.post(`/api/orders/1/quotes/${result.body.quotes[0].id}/select`).expect(200);
  await api.patch('/api/orders/1').send(patch).expect(200).expect(r => {
    expect(r.body.quotes).toEqual([]);
    expect(r.body.selectedQuote).toBeNull();
  });
});
it('recota substituindo a rodada; seleção única; indisponíveis bloqueadas; snapshot mantido', async () => {
  let result = await api.post('/api/orders/8/quotes').expect(201);
  const unavailable = result.body.quotes.find(q => !q.available);
  await api.post(`/api/orders/8/quotes/${unavailable.id}/select`).expect(409).expect(r => expect(r.body.error.message).toBe('Esta transportadora não atende este pedido.'));
  await api.post(`/api/orders/1/quotes/${unavailable.id}/select`).expect(404);
  for (const quote of result.body.quotes.filter(q => q.available).slice(0, 2)) await api.post(`/api/orders/8/quotes/${quote.id}/select`).expect(200);
  expect(db.prepare('SELECT count(*) n FROM quotes WHERE order_id=8 AND is_selected=1').get().n).toBe(1);
  await api.patch('/api/carriers/1').send({
    name: 'Alfa Renomeada'
  }).expect(200);
  await api.get('/api/orders/8').expect(200).expect(r => expect(r.body.quotes.some(q => q.carrierName === 'Alfa Transportes')).toBe(true));
  const oldId = result.body.quotes[0].id;
  result = await api.post('/api/orders/8/quotes').expect(201);
  expect(result.body.quotes).toHaveLength(4);
  expect(result.body.quotes[0].id).not.toBe(oldId);
  expect(db.prepare('SELECT count(*) n FROM quotes WHERE order_id=8 AND is_selected=1').get().n).toBe(0);
});
it('prazo e selos são calculados na leitura; permite selecionar fora do prazo e desmarcar na inicial', async () => {
  const result = await api.post('/api/orders/7/quotes').expect(201);
  const gamma = result.body.quotes.find(q => q.carrierId === 3);
  expect(gamma.meetsDeadline).toBe(false);
  await api.post(`/api/orders/7/quotes/${gamma.id}/select`).expect(200);
  await api.patch('/api/orders/7').send({
    desiredDeadlineDate: '2026-11-20'
  }).expect(200).expect(r => expect(r.body.selectedQuote.meetsDeadline).toBe(true));
  await api.delete('/api/orders/7/selection').expect(200).expect(r => expect(r.body.selectedQuote).toBeNull());
});
it('lista e pesquisa todos os campos especificados, mantendo ordenação', async () => {
  const rows = (await api.get('/api/orders').expect(200)).body;
  expect(rows.map(o => o.id)).toEqual([7, 4, 1, 6, 2, 5, 3, 8]);
  for (const search of ['ped-0001', 'marina', 'comercial', 'central', 'campinas', 'gama']) {
    const result = await api.get('/api/orders').query({
      search
    }).expect(200);
    expect(result.body.length).toBeGreaterThan(0);
  }
  await api.get('/api/orders?search=inexistente').expect(200).expect(r => expect(r.body).toEqual([]));
});
it('toca updatedAt nas alterações, apaga cotações com exclusão e trata ausência de transportadoras ativas', async () => {
  db.prepare('UPDATE orders SET updated_at=? WHERE id=1').run('2000-01-01T00:00:00Z');
  await api.post('/api/orders/1/quotes').expect(201);
  expect((await api.get('/api/orders/1')).body.updatedAt).not.toBe('2000-01-01T00:00:00Z');
  await api.delete('/api/orders/1').expect(204);
  expect(db.prepare('SELECT count(*) n FROM quotes WHERE order_id=1').get().n).toBe(0);
  db.prepare('UPDATE carriers SET active=0').run();
  await api.post('/api/orders/2/quotes').expect(201).expect(r => expect(r.body.quotes).toEqual([]));
});
it('CSV: BOM, cabeçalhos, CRLF, decimais, escape e proteção de fórmulas; ignora busca', async () => {
  db.prepare('UPDATE orders SET requester_sector=?,requester_name=?,volume_m3=? WHERE id=1').run('=SOMA(1;2)', 'Pessoa; "fictícia"', 1.234);
  const response = await api.get('/api/orders/export.csv?search=inexistente').buffer(true).parse((res, done) => {
    const chunks = [];
    res.on('data', chunk => chunks.push(chunk));
    res.on('end', () => done(null, Buffer.concat(chunks)));
  }).expect(200);
  expect(response.headers['content-type']).toContain('text/csv');
  expect(response.headers['content-disposition']).toContain('cotalog-pedidos.csv');
  const bytes = response.body;
  expect([...bytes.subarray(0, 3)]).toEqual([239, 187, 191]);
  const text = bytes.toString('utf8');
  expect(text.slice(1).split('\r\n')[0]).toBe(columns.join(';'));
  expect(text.split('\r\n')).toHaveLength(10);
  expect(text).toContain('"\'=SOMA(1;2)"');
  expect(text).toContain('"Pessoa; ""fictícia"""');
  expect(text).toContain('1,234');
  expect(text).toContain('171,25');
  for (const cell of ['=1', '+1', '-1', '@1']) expect(escapeCell(cell)).toBe("'" + cell);
  expect(escapeCell('duas\nlinhas')).toBe('"duas\nlinhas"');
});
it('rejeita casas decimais adicionais mesmo próximas de um milésimo', async () => {
  for (const patch of [{
    weightKg: 1.000000001
  }, {
    volumeM3: 1.000000001
  }]) await api.post('/api/orders').send({
    ...data,
    ...patch
  }).expect(400);
});
