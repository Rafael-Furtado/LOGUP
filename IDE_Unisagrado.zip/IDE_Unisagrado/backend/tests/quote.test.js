import { describe, it, expect, beforeEach, afterEach } from 'vitest';
import { connect } from '../src/db/connection.js';
import { seed } from '../src/db/seed.js';
import { camelRow } from '../src/domain/quoteService.js';
import { calculateQuotes } from '../src/domain/quote.js';
import { variablePrice } from '../src/domain/money.js';
import { todayISO, addDays } from '../src/domain/dates.js';
let db;
beforeEach(() => {
  db = connect(':memory:');
  seed(db, '2026-11-10');
});
afterEach(() => db.close());
function quote(weight, region = 1, days = 20) {
  return calculateQuotes({
    weightKg: weight,
    destinationRegionId: region,
    desiredDeadlineDate: addDays('2026-11-10', days)
  }, db.prepare('SELECT * FROM carriers').all().map(camelRow), db.prepare('SELECT * FROM rate_rules').all().map(camelRow), '2026-11-10');
}
describe('Exemplos oficiais', () => {
  it.each([['E1', 20, 1, 7, [6300, 7000, 7200, 8200], ['Gama Cargas', 'Delta Log', 'Alfa Transportes', 'Beta Express']], ['E2', 5, 1, 10, [4800, 5200, 5300, 5500], ['Delta Log', 'Beta Express', 'Alfa Transportes', 'Gama Cargas']], ['E3', 300, 4, 15, [70100, 79100, 83800, null], ['Gama Cargas', 'Alfa Transportes', 'Delta Log', 'Beta Express']], ['E4', 15, 5, 20, [7895, 8960, 10125, null], ['Gama Cargas', 'Alfa Transportes', 'Beta Express', 'Delta Log']], ['E5', 60, 1, 4, [13800, 14200, 14300, 15200], ['Beta Express', 'Delta Log', 'Gama Cargas', 'Alfa Transportes']]])('%s: valores, ordenação, selos e prazo', (_, weight, region, days, prices, names) => {
    const result = quote(weight, region, days);
    expect(result.map(q => q.priceCents)).toEqual(prices);
    expect(result.map(q => q.carrierName)).toEqual(names);
    expect(result[0].badges).toContain('cheapest');
    const fastest = result.filter(q => q.badges.includes('fastest'));
    expect(fastest).toHaveLength(1);
    expect(fastest[0].carrierName).toBe(region === 4 ? 'Alfa Transportes' : 'Beta Express');
    for (const q of result.filter(q => q.available)) expect(q.meetsDeadline).toBe(q.estimatedDeliveryDate <= addDays('2026-11-10', days));
    if (region === 4) expect(result[3].unavailableReason).toBe('Peso fora das faixas cadastradas');
    if (region === 5) expect(result[3].unavailableReason).toBe('Sem tabela para a região de destino');
    if (weight === 60) {
      expect(result[0].badges).toEqual(['cheapest', 'fastest']);
      expect(result.find(q => q.carrierId === 3).meetsDeadline).toBe(false);
    }
  });
  it('E6: arredondamento inteiro', () => expect(variablePrice(12.345, 368)).toBe(4543));
  it('respeita limites exclusivos/inclusivos e empates', () => {
    expect(quote(10).find(q => q.carrierId === 1).priceCents).toBe(5300);
    expect(quote(10.001).find(q => q.carrierId === 1).priceCents).toBe(5300);
    const rules = [{
      carrierId: 1,
      regionId: 1,
      minWeightKg: 10,
      maxWeightKg: 20,
      pricePerKgCents: 100,
      minChargeCents: 0,
      fixedFeeCents: 0,
      leadTimeDays: 1
    }];
    const carriers = [{
      id: 1,
      name: 'Teste',
      active: 1
    }];
    expect(calculateQuotes({
      weightKg: 10,
      destinationRegionId: 1
    }, carriers, rules, '2026-11-10')[0].available).toBe(false);
    expect(calculateQuotes({
      weightKg: 20,
      destinationRegionId: 1
    }, carriers, rules, '2026-11-10')[0].available).toBe(true);
    const tied = calculateQuotes({
      weightKg: 20,
      destinationRegionId: 1,
      desiredDeadlineDate: '2026-11-20'
    }, [...carriers, {
      id: 2,
      name: 'Teste B',
      active: 1
    }], [...rules, {
      ...rules[0],
      carrierId: 2
    }], '2026-11-10');
    expect(tied.every(q => q.badges.length === 2)).toBe(true);
  });
});
it('seed possui contagens e etapas exatas', () => {
  for (const [table, total] of [['carriers', 4], ['regions', 5], ['locations', 11], ['orders', 8], ['rate_rules', 71]]) expect(db.prepare(`SELECT count(*) n FROM ${table}`).get().n).toBe(total);
  expect(db.prepare('SELECT stage_id,count(*) n FROM orders GROUP BY stage_id ORDER BY stage_id').all().map(r => r.n)).toEqual([4, 1, 1, 1, 1]);
  expect(db.prepare('SELECT count(*) n FROM quotes WHERE is_selected=1').get().n).toBe(4);
});
it('hoje considera São Paulo e soma dias corridos', () => {
  expect(todayISO(new Date('2026-11-11T01:00:00Z'))).toBe('2026-11-10');
  expect(addDays('2026-12-31', 2)).toBe('2027-01-02');
});
