import { vi } from 'vitest';
vi.setConfig({
  testTimeout: 15000
});
import { beforeEach, afterEach, it, expect } from 'vitest';
import request from 'supertest';
import { connect } from '../src/db/connection.js';
import { seed } from '../src/db/seed.js';
import { createApp } from '../src/app.js';
let db, api;
beforeEach(() => {
  db = connect(':memory:');
  seed(db, '2026-11-10');
  api = request(createApp(db, {
    today: () => '2026-11-10'
  }));
});
afterEach(() => db.close());
it('cadastros: criar, ler, editar e excluir; unicidade sem diferenciar caixa', async () => {
  const carrier = await api.post('/api/carriers').send({
    name: 'Teste Fictício'
  }).expect(201);
  expect(carrier.body.active).toBe(true);
  await api.post('/api/carriers').send({
    name: 'teste fictício'
  }).expect(409).expect(r => expect(r.body.error.fields.name).toBe('Já existe um registro com este nome.'));
  await api.patch('/api/carriers/' + carrier.body.id).send({
    active: false,
    name: 'Renomeada'
  }).expect(200).expect(r => expect(r.body.active).toBe(false));
  await api.delete('/api/carriers/' + carrier.body.id).expect(204);
  const region = await api.post('/api/regions').send({
    name: 'Região fictícia'
  }).expect(201);
  const location = await api.post('/api/locations').send({
    name: 'Local fictício',
    uf: 'SP',
    regionId: region.body.id
  }).expect(201);
  expect(location.body.regionName).toBe('Região fictícia');
  await api.patch('/api/locations/' + location.body.id).send({
    uf: 'RJ'
  }).expect(200);
  await api.delete('/api/locations/' + location.body.id).expect(204);
  await api.patch('/api/regions/' + region.body.id).send({
    name: 'Outra região'
  }).expect(200);
  await api.delete('/api/regions/' + region.body.id).expect(204);
});
it('regras: adjacência aceita, sobreposição rejeitada e edição exclui a própria regra', async () => {
  const data = {
    carrierId: 1,
    regionId: 1,
    minWeightKg: 1000,
    maxWeightKg: 2000,
    pricePerKgCents: 100,
    minChargeCents: 0,
    fixedFeeCents: 0,
    leadTimeDays: 1
  };
  const rule = await api.post('/api/rate-rules').send(data).expect(201);
  await api.patch('/api/rate-rules/' + rule.body.id).send({
    leadTimeDays: 2
  }).expect(200);
  await api.post('/api/rate-rules').send({
    ...data,
    minWeightKg: 5,
    maxWeightKg: 15
  }).expect(400).expect(r => expect(r.body.error.fields.minWeightKg).toBe('Já existe uma faixa de peso dessa transportadora para essa região que se sobrepõe a esta.'));
  await api.get('/api/rate-rules?carrierId=1&regionId=1').expect(200).expect(r => expect(r.body).toHaveLength(5));
  await api.delete('/api/rate-rules/' + rule.body.id).expect(204);
});
it('valida limites, campos obrigatórios e referências', async () => {
  for (const [url, data, field] of [['carriers', {}, 'name'], ['locations', {
    name: 'Teste',
    uf: 'XX',
    regionId: 1
  }, 'uf'], ['locations', {
    name: 'Teste',
    uf: 'SP',
    regionId: 999
  }, 'regionId'], ['rate-rules', {
    carrierId: 1,
    regionId: 1,
    minWeightKg: 0,
    maxWeightKg: 0,
    pricePerKgCents: 0,
    minChargeCents: -1,
    fixedFeeCents: 0,
    leadTimeDays: 61
  }, 'pricePerKgCents']]) await api.post('/api/' + url).send(data).expect(400).expect(r => expect(r.body.error.fields[field]).toBeTruthy());
  await api.patch('/api/carriers/999').send({
    name: 'Teste'
  }).expect(404);
  await api.get('/api/inexistente').expect(404);
  await api.post('/api/regions').set('Content-Type', 'application/json').send('{').expect(400);
});
it('etapas: criar, trocar marcas, rejeitar desmarcar e ambas as marcas, reordenar e excluir', async () => {
  const stage = await api.post('/api/stages').send({
    name: 'Em separação'
  }).expect(201);
  expect(stage.body.position).toBe(6);
  await api.patch('/api/stages/' + stage.body.id).send({
    isInitial: true
  }).expect(200);
  await api.patch('/api/stages/' + stage.body.id).send({
    isInitial: false
  }).expect(409);
  await api.patch('/api/stages/2').send({
    isFinal: true
  }).expect(200);
  await api.patch('/api/stages/2').send({
    isFinal: false
  }).expect(409);
  await api.patch('/api/stages/2').send({
    isInitial: true
  }).expect(400);
  let rows = (await api.get('/api/stages')).body;
  expect(rows.filter(s => s.isInitial)).toHaveLength(1);
  expect(rows.filter(s => s.isFinal)).toHaveLength(1);
  const ids = rows.map(s => s.id).reverse();
  await api.put('/api/stages/order').send({
    ids
  }).expect(200).expect(r => {
    expect(r.body.map(s => s.id)).toEqual(ids);
    expect(r.body.map(s => s.position)).toEqual([1, 2, 3, 4, 5, 6]);
  });
  await api.put('/api/stages/order').send({
    ids: [1, 1]
  }).expect(400);
  await api.delete('/api/stages/2').expect(409);
  await api.delete('/api/stages/1').expect(409).expect(r => expect(r.body.error.message).toBe('Mova os pedidos desta etapa antes de excluí-la.'));
  await api.patch('/api/stages/1').send({
    isInitial: true
  }).expect(200);
  await api.delete('/api/stages/' + stage.body.id).expect(204);
  await api.delete('/api/stages/1').expect(409);
});
it('exclusões em uso bloqueadas e transportadora sem cotações remove regras em cascata', async () => {
  await api.delete('/api/carriers/1').expect(409).expect(r => expect(r.body.error.message).toContain('Desative-a'));
  await api.delete('/api/regions/1').expect(409);
  await api.delete('/api/locations/1').expect(409);
  db.prepare('DELETE FROM quotes WHERE carrier_id=1').run();
  await api.delete('/api/carriers/1').expect(204);
  expect(db.prepare('SELECT count(*) n FROM rate_rules WHERE carrier_id=1').get().n).toBe(0);
});
it('unicidade também considera letras acentuadas e timestamps são ISO UTC', async () => {
  await api.post('/api/regions').send({
    name: 'REGIÃO FICTÍCIA'
  }).expect(201);
  await api.post('/api/regions').send({
    name: 'região fictícia'
  }).expect(409);
  await api.get('/api/carriers').expect(200).expect(r => expect(r.body.every(c => /^\d{4}-\d{2}-\d{2}T.*Z$/.test(c.createdAt))).toBe(true));
});
