import { initialize, stageNames } from './init.js';
import { addDays, todayISO } from '../domain/dates.js';
import { quoteOrder } from '../domain/quoteService.js';
export function seed(db, today = todayISO()) {
  initialize(db);
  db.transaction(() => {
    for (const table of ['quotes', 'orders', 'rate_rules', 'locations', 'carriers', 'regions', 'stages']) db.prepare(`DELETE FROM ${table}`).run();
    db.exec('DELETE FROM sqlite_sequence');
    stageNames.forEach((name, i) => db.prepare('INSERT INTO stages (name,position,is_initial,is_final) VALUES (?,?,?,?)').run(name, i + 1, Number(i === 0), Number(i === 4)));
    const regions = ['Sudeste', 'Sul', 'Centro-Oeste', 'Nordeste', 'Norte'];
    regions.forEach(name => db.prepare('INSERT INTO regions(name) VALUES (?)').run(name));
    const locations = [['CD Central (fictício)', 'SP', 1], ['São Paulo', 'SP', 1], ['Campinas', 'SP', 1], ['Bauru', 'SP', 1], ['Rio de Janeiro', 'RJ', 1], ['Belo Horizonte', 'MG', 1], ['Curitiba', 'PR', 2], ['Porto Alegre', 'RS', 2], ['Goiânia', 'GO', 3], ['Salvador', 'BA', 4], ['Manaus', 'AM', 5]];
    locations.forEach(row => db.prepare('INSERT INTO locations(name,uf,region_id) VALUES (?,?,?)').run(...row));
    const carriers = [['Alfa Transportes', [450, 320, 240, 180], 4500, 800, 3], ['Beta Express', [420, 350, 210], 4000, 1200, 2], ['Gama Cargas', [400, 290, 230, 160], 5000, 500, 5], ['Delta Log', [480, 300, 220, 190], 3800, 1000, 4]];
    const bands = [[0, 10], [10, 50], [50, 200], [200, 1000]];
    carriers.forEach(([name, prices, minimum, fee, days], i) => {
      db.prepare('INSERT INTO carriers(name) VALUES (?)').run(name);
      [100, 115, 120, 145, 170].forEach((percent, j) => {
        if (i === 3 && j === 4) return;
        prices.forEach((base, k) => db.prepare('INSERT INTO rate_rules(carrier_id,region_id,min_weight_kg,max_weight_kg,price_per_kg_cents,min_charge_cents,fixed_fee_cents,lead_time_days) VALUES (?,?,?,?,?,?,?,?)').run(i + 1, j + 1, ...bands[k], Math.floor((base * percent + 50) / 100), minimum, fee, days + [0, 1, 2, 3, 5][j]));
      });
    });
    const orders = [['Comercial', 'Marina Souza', 3, 20, 7, 1, null], ['Compras', 'Carlos Lima', 7, 5, 10, 1, null], ['Atendimento', 'Paula Reis', 10, 300, 15, 2, 3], ['Produção', 'João Alves', 5, 45.5, 6, 3, 2], ['Comercial', 'Marina Souza', 8, 120, 12, 4, 1], ['Compras', 'Carlos Lima', 9, 8, 9, 5, 4], ['Atendimento', 'Paula Reis', 6, 60, 4, 1, null], ['Produção', 'João Alves', 11, 15, 20, 1, null]];
    orders.forEach(([sector, name, destination, weight, days, stage, carrier], i) => {
      const now = new Date().toISOString();
      db.prepare('INSERT INTO orders(requester_sector,requester_name,origin_location_id,destination_location_id,weight_kg,desired_deadline_date,stage_id,created_at,updated_at) VALUES (?,?,1,?,?,?,1,?,?)').run(sector, name, destination, weight, addDays(today, days), now, now);
      if (carrier) {
        quoteOrder(db, i + 1, today);
        db.prepare('UPDATE quotes SET is_selected=1 WHERE order_id=? AND carrier_id=?').run(i + 1, carrier);
        db.prepare('UPDATE orders SET stage_id=?,updated_at=? WHERE id=?').run(stage, now, i + 1);
      }
    });
  })();
}
