import { rmSync } from 'node:fs';
import { connect, defaultPath } from './connection.js';
import { seed } from './seed.js';
const path = process.env.DB_PATH || defaultPath;
if (path !== ':memory:') rmSync(path, {
  force: true
});
const db = connect(path);
seed(db);
db.close();
console.log('Banco recriado com dados inteiramente fictícios.');
