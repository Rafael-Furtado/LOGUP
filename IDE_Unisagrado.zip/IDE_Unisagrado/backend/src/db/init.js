import { readFileSync } from 'node:fs';
export const stageNames = ['A cotar', 'Cotado', 'Aguardando aprovação', 'Despachado', 'Entregue'];
export function initialize(db) {
  db.exec(readFileSync(new URL('./schema.sql', import.meta.url), 'utf8'));
  if (!db.prepare('SELECT count(*) AS n FROM stages').get().n) {
    db.transaction(() => stageNames.forEach((name, index) => db.prepare('INSERT INTO stages (name, position, is_initial, is_final) VALUES (?, ?, ?, ?)').run(name, index + 1, Number(index === 0), Number(index === 4))))();
  }
  return db;
}
