import Database from 'better-sqlite3';
import { mkdirSync } from 'node:fs';
import { dirname, resolve } from 'node:path';
import { fileURLToPath } from 'node:url';
export const defaultPath = fileURLToPath(new URL('../../data/cotalog.db', import.meta.url));
export function connect(path = process.env.DB_PATH || defaultPath) {
  if (path !== ':memory:') mkdirSync(dirname(resolve(path)), {
    recursive: true
  });
  const db = new Database(path);
  db.pragma('foreign_keys = ON');
  return db;
}
