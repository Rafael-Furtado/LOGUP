PRAGMA foreign_keys = ON;
CREATE TABLE IF NOT EXISTS carriers (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  name TEXT NOT NULL UNIQUE COLLATE NOCASE,
  active INTEGER NOT NULL DEFAULT 1,
  created_at TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS regions (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  name TEXT NOT NULL UNIQUE COLLATE NOCASE
);

CREATE TABLE IF NOT EXISTS locations (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  name TEXT NOT NULL COLLATE NOCASE,
  uf TEXT NOT NULL,
  region_id INTEGER NOT NULL REFERENCES regions(id) ON DELETE RESTRICT,
  UNIQUE (name, uf)
);

CREATE TABLE IF NOT EXISTS rate_rules (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  carrier_id INTEGER NOT NULL REFERENCES carriers(id) ON DELETE CASCADE,
  region_id INTEGER NOT NULL REFERENCES regions(id) ON DELETE RESTRICT,
  min_weight_kg REAL NOT NULL,          -- exclusivo
  max_weight_kg REAL NOT NULL,          -- inclusivo
  price_per_kg_cents INTEGER NOT NULL,
  min_charge_cents INTEGER NOT NULL,
  fixed_fee_cents INTEGER NOT NULL,
  lead_time_days INTEGER NOT NULL
);

CREATE TABLE IF NOT EXISTS stages (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  name TEXT NOT NULL UNIQUE COLLATE NOCASE,
  position INTEGER NOT NULL,
  is_initial INTEGER NOT NULL DEFAULT 0,
  is_final INTEGER NOT NULL DEFAULT 0
);

CREATE TABLE IF NOT EXISTS orders (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  requester_sector TEXT NOT NULL,
  requester_name TEXT NOT NULL,
  origin_location_id INTEGER NOT NULL REFERENCES locations(id) ON DELETE RESTRICT,
  destination_location_id INTEGER NOT NULL REFERENCES locations(id) ON DELETE RESTRICT,
  weight_kg REAL NOT NULL,
  volume_m3 REAL,
  desired_deadline_date TEXT NOT NULL,
  notes TEXT,
  stage_id INTEGER NOT NULL REFERENCES stages(id) ON DELETE RESTRICT,
  created_at TEXT NOT NULL DEFAULT (datetime('now')),
  updated_at TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS quotes (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  order_id INTEGER NOT NULL REFERENCES orders(id) ON DELETE CASCADE,
  carrier_id INTEGER NOT NULL REFERENCES carriers(id) ON DELETE RESTRICT,
  carrier_name TEXT NOT NULL,           -- cópia (snapshot) do nome na hora da cotação
  available INTEGER NOT NULL,
  unavailable_reason TEXT,
  price_cents INTEGER,
  lead_time_days INTEGER,
  estimated_delivery_date TEXT,
  is_selected INTEGER NOT NULL DEFAULT 0,
  created_at TEXT NOT NULL DEFAULT (datetime('now'))
);
CREATE UNIQUE INDEX IF NOT EXISTS one_selected_quote_per_order
  ON quotes(order_id) WHERE is_selected = 1;

