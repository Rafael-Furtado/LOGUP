export class ApiError extends Error {
  constructor(status, message, fields) {
    super(message);
    this.status = status;
    this.fields = fields;
  }
}
export const invalid = fields => new ApiError(400, 'Dados inválidos.', fields);
export const conflict = message => new ApiError(409, message);
export function errorHandler(error, req, res, next) {
  if (error.type === 'entity.parse.failed') error = invalid({
    body: 'Informe um JSON válido.'
  });
  if (error.code?.startsWith('SQLITE_CONSTRAINT_UNIQUE')) error = new ApiError(409, 'Já existe um registro com este nome.', {
    name: 'Já existe um registro com este nome.'
  });
  if (error.code?.startsWith('SQLITE_CONSTRAINT_FOREIGNKEY')) error = conflict('Este registro está em uso.');
  const status = error.status && [400, 404, 409].includes(error.status) ? error.status : 500;
  if (status === 500) console.error(error);
  res.status(status).json({
    error: {
      code: {
        400: 'VALIDATION_ERROR',
        404: 'NOT_FOUND',
        409: 'CONFLICT'
      }[status] || 'INTERNAL_ERROR',
      message: status === 500 ? 'Erro interno.' : error.message,
      ...(error.fields ? {
        fields: error.fields
      } : {})
    }
  });
}
export function find(db, table, id) {
  const row = db.prepare(`SELECT * FROM ${table} WHERE id=?`).get(id);
  if (!row) throw new ApiError(404, 'Registro não encontrado.');
  return row;
}
export function assertUniqueName(db, table, data, id = 0) {
  if (!data.name) return;
  const same = db.prepare(`SELECT * FROM ${table} WHERE id!=?`).all(id).some(row => row.name.toLocaleLowerCase('pt-BR') === data.name.toLocaleLowerCase('pt-BR') && (table !== 'locations' || row.uf === data.uf));
  if (same) throw new ApiError(409, 'Já existe um registro com este nome.', {
    name: 'Já existe um registro com este nome.'
  });
}
