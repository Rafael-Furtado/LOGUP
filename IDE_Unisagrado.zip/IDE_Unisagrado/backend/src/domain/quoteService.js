import { calculateQuotes } from './quote.js';
export const camelRow = row => row && Object.fromEntries(Object.entries(row).map(([key, value]) => [key.replace(/_([a-z])/g, (_, letter) => letter.toUpperCase()), /_at$/.test(key) && typeof value === 'string' && !value.includes('T') ? value.replace(' ', 'T') + 'Z' : value]));
export function quoteOrder(db, orderId, today) {
  return db.transaction(() => {
    const order = camelRow(db.prepare('SELECT o.*, l.region_id AS destination_region_id FROM orders o JOIN locations l ON l.id=o.destination_location_id WHERE o.id=?').get(orderId));
    const quotes = calculateQuotes(order, db.prepare('SELECT * FROM carriers').all().map(camelRow), db.prepare('SELECT * FROM rate_rules').all().map(camelRow), today);
    db.prepare('DELETE FROM quotes WHERE order_id=?').run(orderId);
    const insert = db.prepare('INSERT INTO quotes (order_id, carrier_id, carrier_name, available, unavailable_reason, price_cents, lead_time_days, estimated_delivery_date, created_at) VALUES (?,?,?,?,?,?,?,?,?)');
    for (const q of quotes) insert.run(orderId, q.carrierId, q.carrierName, Number(q.available), q.unavailableReason, q.priceCents, q.leadTimeDays, q.estimatedDeliveryDate, new Date().toISOString());
    db.prepare('UPDATE orders SET updated_at=? WHERE id=?').run(new Date().toISOString(), orderId);
    return quotes;
  })();
}
