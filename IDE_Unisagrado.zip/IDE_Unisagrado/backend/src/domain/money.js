export function variablePrice(weightKg, pricePerKgCents) {
  const weightGrams = Math.round(weightKg * 1000);
  return Math.floor((weightGrams * pricePerKgCents + 500) / 1000);
}
