import { find } from '../middleware/errors.js';
import { camelRow } from './quoteService.js';
import { decorateQuotes } from './quote.js';
export function readOrder(db, id, details = true) {
  const order = camelRow(find(db, 'orders', id));
  const origin = camelRow(find(db, 'locations', order.originLocationId));
  const destination = camelRow(find(db, 'locations', order.destinationLocationId));
  const stage = camelRow(find(db, 'stages', order.stageId));
  const quotes = decorateQuotes(db.prepare('SELECT * FROM quotes WHERE order_id=?').all(id).map(row => {
    const q = camelRow(row);
    return {
      id: q.id,
      carrierId: q.carrierId,
      carrierName: q.carrierName,
      available: Boolean(q.available),
      unavailableReason: q.unavailableReason,
      priceCents: q.priceCents,
      leadTimeDays: q.leadTimeDays,
      estimatedDeliveryDate: q.estimatedDeliveryDate,
      isSelected: Boolean(q.isSelected)
    };
  }), order.desiredDeadlineDate);
  return {
    id: order.id,
    code: 'PED-' + String(order.id).padStart(4, '0'),
    requesterSector: order.requesterSector,
    requesterName: order.requesterName,
    origin: {
      id: origin.id,
      name: origin.name,
      uf: origin.uf
    },
    destination: {
      ...destination,
      regionName: find(db, 'regions', destination.regionId).name
    },
    weightKg: order.weightKg,
    volumeM3: order.volumeM3,
    desiredDeadlineDate: order.desiredDeadlineDate,
    notes: order.notes,
    stage: {
      id: stage.id,
      name: stage.name,
      isInitial: Boolean(stage.isInitial),
      isFinal: Boolean(stage.isFinal)
    },
    selectedQuote: quotes.find(q => q.isSelected) || null,
    quotesCount: quotes.length,
    createdAt: order.createdAt,
    updatedAt: order.updatedAt,
    ...(details ? {
      quotes
    } : {})
  };
}
export function listOrders(db, search = '') {
  const rows = db.prepare('SELECT id FROM orders ORDER BY desired_deadline_date,id').all().map(row => readOrder(db, row.id, false));
  const needle = search.toLocaleLowerCase('pt-BR');
  return rows.filter(o => [o.code, o.requesterName, o.requesterSector, o.origin.name, o.destination.name, o.selectedQuote?.carrierName || ''].some(value => value.toLocaleLowerCase('pt-BR').includes(needle)));
}
export function touch(db, id) {
  db.prepare('UPDATE orders SET updated_at=? WHERE id=?').run(new Date().toISOString(), id);
}
