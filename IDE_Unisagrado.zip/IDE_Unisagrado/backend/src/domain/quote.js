import { variablePrice } from './money.js';
import { addDays } from './dates.js';
export function decorateQuotes(quotes, desiredDeadlineDate) {
  const available = quotes.filter(q => q.available);
  const cheapest = Math.min(...available.map(q => q.priceCents));
  const fastest = Math.min(...available.map(q => q.leadTimeDays));
  return quotes.map(q => ({
    ...q,
    available: Boolean(q.available),
    isSelected: Boolean(q.isSelected),
    meetsDeadline: Boolean(q.available && q.estimatedDeliveryDate <= desiredDeadlineDate),
    badges: q.available ? [...(q.priceCents === cheapest ? ['cheapest'] : []), ...(q.leadTimeDays === fastest ? ['fastest'] : [])] : []
  })).sort((a, b) => Number(b.available) - Number(a.available) || (a.available ? a.priceCents - b.priceCents || a.leadTimeDays - b.leadTimeDays : 0) || a.carrierName.localeCompare(b.carrierName, 'pt-BR'));
}
export function calculateQuotes(order, carriers, rules, today) {
  const quotes = carriers.filter(c => c.active).sort((a, b) => a.name.localeCompare(b.name, 'pt-BR')).map(carrier => {
    const regional = rules.filter(r => r.carrierId === carrier.id && r.regionId === order.destinationRegionId);
    const rule = regional.find(r => r.minWeightKg < order.weightKg && order.weightKg <= r.maxWeightKg);
    const base = {
      carrierId: carrier.id,
      carrierName: carrier.name,
      available: Boolean(rule),
      unavailableReason: null,
      priceCents: null,
      leadTimeDays: null,
      estimatedDeliveryDate: null,
      isSelected: false
    };
    if (!rule) return {
      ...base,
      unavailableReason: regional.length ? 'Peso fora das faixas cadastradas' : 'Sem tabela para a região de destino'
    };
    return {
      ...base,
      priceCents: Math.max(rule.minChargeCents, variablePrice(order.weightKg, rule.pricePerKgCents)) + rule.fixedFeeCents,
      leadTimeDays: rule.leadTimeDays,
      estimatedDeliveryDate: addDays(today, rule.leadTimeDays)
    };
  });
  return decorateQuotes(quotes, order.desiredDeadlineDate);
}
