export const columns = ['Código', 'Setor', 'Solicitante', 'Origem', 'Destino', 'Região de destino', 'Peso (kg)', 'Volume (m³)', 'Prazo desejado', 'Etapa', 'Transportadora selecionada', 'Valor (R$)', 'Prazo da transportadora (dias)', 'Entrega estimada', 'Criado em'];
export function escapeCell(value) {
  let text = value == null ? '' : String(value);
  if (typeof value === 'string' && /^[=+\-@]/.test(text)) text = "'" + text;
  return /[;"\r\n]/.test(text) ? '"' + text.replaceAll('"', '""') + '"' : text;
}
const date = value => value ? value.slice(0, 10).split('-').reverse().join('/') : '';
const decimal = value => value == null ? '' : String(value).replace('.', ',');
export function exportOrders(orders) {
  const rows = orders.map(o => {
    const q = o.selectedQuote;
    return [o.code, o.requesterSector, o.requesterName, o.origin.name, o.destination.name, o.destination.regionName, decimal(o.weightKg), decimal(o.volumeM3), date(o.desiredDeadlineDate), o.stage.name, q?.carrierName || '', q ? (q.priceCents / 100).toFixed(2).replace('.', ',') : '', q?.leadTimeDays ?? '', date(q?.estimatedDeliveryDate), date(o.createdAt)];
  });
  return '\uFEFF' + [columns, ...rows].map(row => row.map(escapeCell).join(';')).join('\r\n') + '\r\n';
}
