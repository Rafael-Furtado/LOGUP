import { fileURLToPath } from 'node:url';
import path from 'node:path';
import orders from './routes/orders.js';
import { todayISO } from './domain/dates.js';
import express from 'express';
import carriers from './routes/carriers.js';
import regions from './routes/regions.js';
import locations from './routes/locations.js';
import rateRules from './routes/rateRules.js';
import stages from './routes/stages.js';
import { errorHandler, ApiError } from './middleware/errors.js';
export function createApp(db, {
  today = todayISO
} = {}) {
  const app = express();
  app.use(express.json());
  app.get('/api/health', (req, res) => res.json({
    status: 'ok'
  }));
  for (const [path, router] of [['carriers', carriers], ['regions', regions], ['locations', locations], ['rate-rules', rateRules], ['stages', stages]]) app.use('/api/' + path, router(db));
  app.use('/api/orders', orders(db, typeof today === 'function' ? today : () => today));
  app.use('/api', (req, res, next) => next(new ApiError(404, 'Rota não encontrada.')));
  const frontendDist = fileURLToPath(new URL('../../frontend/dist/', import.meta.url));
  app.use(express.static(frontendDist));
  app.get('*', (req, res) => res.sendFile(path.join(frontendDist, 'index.html')));
  app.use(errorHandler);
  return app;
}
