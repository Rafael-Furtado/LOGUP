import { createApp } from './app.js';
import { connect } from './db/connection.js';
import { initialize } from './db/init.js';
const db = initialize(connect());
const server = createApp(db).listen(3001, '127.0.0.1', () => console.log('CotaLog disponível em http://localhost:3001'));
function close() {
  server.close(() => {
    db.close();
    process.exit(0);
  });
}
process.on('SIGINT', close);
process.on('SIGTERM', close);
