import { Router } from 'express';
import { z } from 'zod';
import { parse, orderSchema, reference, id } from './validation.js';
import { find, conflict, invalid, ApiError } from '../middleware/errors.js';
import { camelRow, quoteOrder } from '../domain/quoteService.js';
import { readOrder, listOrders, touch } from '../domain/orders.js';
import { write } from './crud.js';
import { exportOrders } from '../csv.js';
export const initialLockMessage = 'Só é possível alterar peso, origem ou destino, recotar ou remover a seleção enquanto o pedido está na etapa inicial.';
export default function orders(db, today) {
  const router = Router();
  const checkInitial = order => {
    if (!find(db, 'stages', order.stage_id).is_initial) throw conflict(initialLockMessage);
  };
  function validateLocations(data) {
    reference(db, 'locations', data.originLocationId, 'originLocationId');
    reference(db, 'locations', data.destinationLocationId, 'destinationLocationId');
  }
  router.get('/export.csv', (req, res) => res.set({
    'Content-Type': 'text/csv; charset=utf-8',
    'Content-Disposition': 'attachment; filename="cotalog-pedidos.csv"'
  }).send(Buffer.from(exportOrders(listOrders(db)), 'utf8')));
  router.get('/', (req, res) => res.json(listOrders(db, typeof req.query.search === 'string' ? req.query.search : '')));
  router.post('/', (req, res) => db.transaction(() => {
    const data = parse(orderSchema, req.body);
    validateLocations(data);
    if (data.desiredDeadlineDate < today()) throw invalid({
      desiredDeadlineDate: 'O prazo desejado não pode ser anterior a hoje.'
    });
    const stage = db.prepare('SELECT id FROM stages WHERE is_initial=1').get();
    const now = new Date().toISOString();
    const orderId = write(db, 'orders', {
      ...data,
      volumeM3: data.volumeM3 ?? null,
      notes: data.notes ?? null,
      stageId: stage.id,
      createdAt: now,
      updatedAt: now
    });
    res.status(201).json(readOrder(db, orderId));
  })());
  router.get('/:id', (req, res) => res.json(readOrder(db, req.params.id)));
  router.patch('/:id', (req, res) => db.transaction(() => {
    const old = find(db, 'orders', req.params.id);
    const data = parse(orderSchema, {
      ...camelRow(old),
      ...req.body
    });
    validateLocations(data);
    const changed = ['weightKg', 'originLocationId', 'destinationLocationId'].some(key => data[key] !== camelRow(old)[key]);
    if (changed) {
      checkInitial(old);
      db.prepare('DELETE FROM quotes WHERE order_id=?').run(old.id);
    }
    write(db, 'orders', {
      ...data,
      updatedAt: new Date().toISOString()
    }, old.id);
    res.json(readOrder(db, old.id));
  })());
  router.delete('/:id', (req, res) => {
    const order = find(db, 'orders', req.params.id);
    db.prepare('DELETE FROM orders WHERE id=?').run(order.id);
    res.status(204).end();
  });
  router.post('/:id/stage', (req, res) => db.transaction(() => {
    const order = find(db, 'orders', req.params.id);
    const {
      stageId
    } = parse(z.object({
      stageId: id()
    }), req.body);
    reference(db, 'stages', stageId, 'stageId');
    if (stageId !== order.stage_id && find(db, 'stages', order.stage_id).is_initial && !db.prepare('SELECT id FROM quotes WHERE order_id=? AND is_selected=1').get(order.id)) throw conflict('Selecione uma cotação antes de avançar o pedido.');
    db.prepare('UPDATE orders SET stage_id=? WHERE id=?').run(stageId, order.id);
    touch(db, order.id);
    res.json(readOrder(db, order.id));
  })());
  router.post('/:id/quotes', (req, res) => {
    const order = find(db, 'orders', req.params.id);
    checkInitial(order);
    quoteOrder(db, order.id, today());
    res.status(201).json({
      quotes: readOrder(db, order.id).quotes
    });
  });
  router.post('/:id/quotes/:quoteId/select', (req, res) => db.transaction(() => {
    const order = find(db, 'orders', req.params.id);
    const quote = find(db, 'quotes', req.params.quoteId);
    if (quote.order_id !== order.id) throw new ApiError(404, 'Cotação não encontrada para este pedido.');
    if (!quote.available) throw conflict('Esta transportadora não atende este pedido.');
    db.prepare('UPDATE quotes SET is_selected=0 WHERE order_id=?').run(order.id);
    db.prepare('UPDATE quotes SET is_selected=1 WHERE id=?').run(quote.id);
    touch(db, order.id);
    res.json(readOrder(db, order.id));
  })());
  router.delete('/:id/selection', (req, res) => db.transaction(() => {
    const order = find(db, 'orders', req.params.id);
    checkInitial(order);
    db.prepare('UPDATE quotes SET is_selected=0 WHERE order_id=?').run(order.id);
    touch(db, order.id);
    res.json(readOrder(db, order.id));
  })());
  return router;
}
