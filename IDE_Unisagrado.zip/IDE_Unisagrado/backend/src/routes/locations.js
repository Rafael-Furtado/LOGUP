import { crud } from './crud.js';
import { locationSchema, reference } from './validation.js';
import { find, conflict } from '../middleware/errors.js';
import { camelRow } from '../domain/quoteService.js';
export default db => crud(db, {
  table: 'locations',
  schema: locationSchema,
  read: id => {
    const row = camelRow(find(db, 'locations', id));
    return {
      ...row,
      regionName: find(db, 'regions', row.regionId).name
    };
  },
  validate: data => reference(db, 'regions', data.regionId, 'regionId'),
  beforeDelete: row => {
    if (db.prepare('SELECT id FROM orders WHERE origin_location_id=? OR destination_location_id=? LIMIT 1').get(row.id, row.id)) throw conflict('Este local está em uso por pedidos.');
  }
});
