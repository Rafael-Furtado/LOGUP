import { crud } from './crud.js';
import { ruleSchema, reference } from './validation.js';
import { invalid } from '../middleware/errors.js';
import { camelRow } from '../domain/quoteService.js';
export const overlapMessage = 'Já existe uma faixa de peso dessa transportadora para essa região que se sobrepõe a esta.';
export default db => crud(db, {
  table: 'rate_rules',
  schema: ruleSchema,
  list: req => {
    let rows = db.prepare('SELECT r.*,c.name AS carrier_name,g.name AS region_name FROM rate_rules r JOIN carriers c ON c.id=r.carrier_id JOIN regions g ON g.id=r.region_id ORDER BY c.name COLLATE NOCASE,g.name COLLATE NOCASE,r.min_weight_kg').all().map(camelRow);
    if (req.query.carrierId !== undefined) rows = rows.filter(r => r.carrierId === Number(req.query.carrierId));
    if (req.query.regionId !== undefined) rows = rows.filter(r => r.regionId === Number(req.query.regionId));
    return rows;
  },
  validate: (data, id = 0) => {
    reference(db, 'carriers', data.carrierId, 'carrierId');
    reference(db, 'regions', data.regionId, 'regionId');
    if (db.prepare('SELECT id FROM rate_rules WHERE carrier_id=? AND region_id=? AND min_weight_kg<? AND ?<max_weight_kg AND id!=?').get(data.carrierId, data.regionId, data.maxWeightKg, data.minWeightKg, id)) throw invalid({
      minWeightKg: overlapMessage
    });
  }
});
