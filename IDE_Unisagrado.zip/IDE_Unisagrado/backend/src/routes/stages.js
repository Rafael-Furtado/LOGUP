import { Router } from 'express';
import { parse, stageSchema, id } from './validation.js';
import { z } from 'zod';
import { find, conflict, invalid, assertUniqueName } from '../middleware/errors.js';
import { camelRow } from '../domain/quoteService.js';
import { write } from './crud.js';
export const stageRow = row => {
  const value = camelRow(row);
  return {
    ...value,
    isInitial: Boolean(value.isInitial),
    isFinal: Boolean(value.isFinal)
  };
};
export default function stages(db) {
  const router = Router();
  const list = () => db.prepare('SELECT * FROM stages ORDER BY position').all().map(stageRow);
  function save(body, old) {
    const data = parse(stageSchema, {
      ...(old ? stageRow(old) : {}),
      ...body
    });
    assertUniqueName(db, 'stages', data, old?.id);
    if (old?.is_initial && body.isInitial === false) throw conflict('Defina outra etapa como inicial em vez de desmarcar esta.');
    if (old?.is_final && body.isFinal === false) throw conflict('Defina outra etapa como final em vez de desmarcar esta.');
    if (data.isInitial) db.prepare('UPDATE stages SET is_initial=0').run();
    if (data.isFinal) db.prepare('UPDATE stages SET is_final=0').run();
    const stageId = write(db, 'stages', {
      ...data,
      ...(!old ? {
        position: db.prepare('SELECT coalesce(max(position),0)+1 n FROM stages').get().n
      } : {})
    }, old?.id);
    return stageRow(find(db, 'stages', stageId));
  }
  router.get('/', (req, res) => res.json(list()));
  router.post('/', (req, res) => res.status(201).json(db.transaction(() => save(req.body))()));
  router.put('/order', (req, res) => db.transaction(() => {
    const data = parse(z.object({
      ids: z.array(id())
    }), req.body);
    const existing = list().map(s => s.id);
    if (data.ids.length !== existing.length || new Set(data.ids).size !== existing.length || existing.some(value => !data.ids.includes(value))) throw invalid({
      ids: 'Informe todos os ids das etapas, sem repetições.'
    });
    data.ids.forEach((value, index) => db.prepare('UPDATE stages SET position=? WHERE id=?').run(index + 1, value));
    res.json(list());
  })());
  router.patch('/:id', (req, res) => res.json(db.transaction(() => save(req.body, find(db, 'stages', req.params.id)))()));
  router.delete('/:id', (req, res) => db.transaction(() => {
    const row = find(db, 'stages', req.params.id);
    if (row.is_initial || row.is_final) throw conflict('Não é possível excluir a etapa inicial ou a final.');
    if (db.prepare('SELECT id FROM orders WHERE stage_id=? LIMIT 1').get(row.id)) throw conflict('Mova os pedidos desta etapa antes de excluí-la.');
    db.prepare('DELETE FROM stages WHERE id=?').run(row.id);
    list().forEach((value, i) => db.prepare('UPDATE stages SET position=? WHERE id=?').run(i + 1, value.id));
    res.status(204).end();
  })());
  return router;
}
