import { z } from 'zod';
import { invalid } from '../middleware/errors.js';
import { validDate } from '../domain/dates.js';
const required = issue => issue.input === undefined || issue.input === null || issue.input === '' ? 'Campo obrigatório.' : 'Informe um valor válido.';
export const text = (min, max) => z.string({
  error: required
}).trim().min(1, 'Campo obrigatório.').min(min, `Informe pelo menos ${min} caracteres.`).max(max, `Informe no máximo ${max} caracteres.`);
export const number = () => z.number({
  error: required
}).finite('Informe um número válido.');
export const id = () => number().int('Informe um identificador inteiro.').positive('Selecione um registro válido.');
export const boolean = () => z.boolean({
  error: 'Informe verdadeiro ou falso.'
});
export const ufs = ['AC', 'AL', 'AP', 'AM', 'BA', 'CE', 'DF', 'ES', 'GO', 'MA', 'MT', 'MS', 'MG', 'PA', 'PB', 'PR', 'PE', 'PI', 'RJ', 'RN', 'RS', 'RO', 'RR', 'SC', 'SP', 'SE', 'TO'];
export const carrierSchema = z.object({
  name: text(2, 80),
  active: boolean().default(true)
});
export const regionSchema = z.object({
  name: text(2, 40)
});
export const locationSchema = z.object({
  name: text(2, 80),
  uf: z.string({
    error: required
  }).refine(v => ufs.includes(v), 'Selecione uma UF válida.'),
  regionId: id()
});
export const ruleSchema = z.object({
  carrierId: id(),
  regionId: id(),
  minWeightKg: number().min(0, 'Informe peso mínimo maior ou igual a zero.'),
  maxWeightKg: number().max(100000, 'Informe peso máximo de até 100000 kg.'),
  pricePerKgCents: number().int('Informe centavos inteiros.').min(1, 'Informe preço por kg maior que zero.'),
  minChargeCents: number().int('Informe centavos inteiros.').min(0, 'Informe um mínimo maior ou igual a zero.'),
  fixedFeeCents: number().int('Informe centavos inteiros.').min(0, 'Informe uma taxa maior ou igual a zero.'),
  leadTimeDays: number().int('Informe dias inteiros.').min(1, 'Informe prazo de pelo menos 1 dia.').max(60, 'Informe prazo de até 60 dias.')
}).refine(v => v.maxWeightKg > v.minWeightKg, {
  path: ['maxWeightKg'],
  message: 'O peso máximo deve ser maior que o mínimo.'
});
export const stageSchema = z.object({
  name: text(2, 30),
  isInitial: boolean().default(false),
  isFinal: boolean().default(false)
}).refine(v => !(v.isInitial && v.isFinal), {
  path: ['isInitial'],
  message: 'Uma etapa não pode ser inicial e final ao mesmo tempo.'
});
const decimal = value => Number(value.toFixed(3)) === value;
export const orderSchema = z.object({
  requesterSector: text(2, 60),
  requesterName: text(2, 80),
  originLocationId: id(),
  destinationLocationId: id(),
  weightKg: number().gt(0, 'Informe um peso maior que zero.').max(100000, 'Informe peso de até 100000 kg.').refine(decimal, 'Informe no máximo 3 casas decimais.'),
  volumeM3: number().gt(0, 'Informe um volume maior que zero.').max(1000, 'Informe volume de até 1000 m³.').refine(decimal, 'Informe no máximo 3 casas decimais.').nullable().optional(),
  desiredDeadlineDate: z.string({
    error: required
  }).min(1, 'Campo obrigatório.').refine(validDate, 'Informe uma data válida.'),
  notes: z.string({
    error: 'Informe um texto válido.'
  }).max(500, 'Informe no máximo 500 caracteres.').nullable().optional()
}).refine(v => v.originLocationId !== v.destinationLocationId, {
  path: ['destinationLocationId'],
  message: 'Origem e destino devem ser diferentes.'
});
export function parse(schema, value) {
  const result = schema.safeParse(value);
  if (!result.success) {
    const fields = {};
    for (const issue of result.error.issues) {
      const key = issue.path.join('.') || 'body';
      if (!fields[key]) fields[key] = issue.message;
    }
    throw invalid(fields);
  }
  return result.data;
}
export function reference(db, table, value, field) {
  if (!db.prepare(`SELECT id FROM ${table} WHERE id=?`).get(value)) throw invalid({
    [field]: 'Selecione um registro existente.'
  });
}
