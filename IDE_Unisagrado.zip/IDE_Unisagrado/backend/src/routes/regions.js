import { crud } from './crud.js';
import { regionSchema } from './validation.js';
import { conflict } from '../middleware/errors.js';
export default db => crud(db, {
  table: 'regions',
  schema: regionSchema,
  beforeDelete: row => {
    if (db.prepare('SELECT id FROM locations WHERE region_id=? UNION ALL SELECT id FROM rate_rules WHERE region_id=? LIMIT 1').get(row.id, row.id)) throw conflict('Esta região está em uso por locais ou regras de custo.');
  }
});
