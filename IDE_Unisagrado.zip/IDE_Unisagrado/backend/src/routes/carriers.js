import { crud } from './crud.js';
import { carrierSchema } from './validation.js';
import { find, conflict } from '../middleware/errors.js';
import { camelRow } from '../domain/quoteService.js';
export default db => crud(db, {
  table: 'carriers',
  schema: carrierSchema,
  validate: (data, id) => {
    if (!id) data.active = true;
  },
  read: id => {
    const row = camelRow(find(db, 'carriers', id));
    return {
      ...row,
      active: Boolean(row.active)
    };
  },
  beforeDelete: row => {
    if (db.prepare('SELECT id FROM quotes WHERE carrier_id=? LIMIT 1').get(row.id)) throw conflict('Esta transportadora possui cotações registradas. Desative-a em vez de excluir.');
  }
});
