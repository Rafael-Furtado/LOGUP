import { Router } from 'express';
import { camelRow } from '../domain/quoteService.js';
import { assertUniqueName, find } from '../middleware/errors.js';
import { parse } from './validation.js';
export const snake = key => key.replace(/[A-Z]/g, letter => '_' + letter.toLowerCase());
export function write(db, table, data, id) {
  const entries = Object.entries(data).map(([key, value]) => [snake(key), typeof value === 'boolean' ? Number(value) : value]);
  if (id !== undefined) db.prepare(`UPDATE ${table} SET ${entries.map(([key]) => `${key}=?`).join(',')} WHERE id=?`).run(...entries.map(([, v]) => v), id);else id = Number(db.prepare(`INSERT INTO ${table} (${entries.map(([key]) => key).join(',')}) VALUES (${entries.map(() => '?').join(',')})`).run(...entries.map(([, v]) => v)).lastInsertRowid);
  return id;
}
export function crud(db, {
  table,
  schema,
  list,
  read,
  validate = () => {},
  beforeDelete = () => {}
}) {
  const router = Router();
  const get = id => read ? read(id) : camelRow(find(db, table, id));
  router.get('/', (req, res) => res.json(list ? list(req) : db.prepare(`SELECT * FROM ${table} ORDER BY name COLLATE NOCASE`).all().map(row => get(row.id))));
  router.post('/', (req, res) => db.transaction(() => {
    const data = parse(schema, req.body);
    assertUniqueName(db, table, data);
    validate(data);
    const id = write(db, table, data);
    res.status(201).json(get(id));
  })());
  router.patch('/:id', (req, res) => db.transaction(() => {
    const old = get(req.params.id);
    const data = parse(schema, {
      ...old,
      ...req.body
    });
    assertUniqueName(db, table, data, old.id);
    validate(data, old.id);
    write(db, table, data, old.id);
    res.json(get(old.id));
  })());
  router.delete('/:id', (req, res) => db.transaction(() => {
    const row = find(db, table, req.params.id);
    beforeDelete(row);
    db.prepare(`DELETE FROM ${table} WHERE id=?`).run(row.id);
    res.status(204).end();
  })());
  return router;
}
