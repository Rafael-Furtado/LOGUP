# CotaLog — Especificação completa para o agente de IA

> Salve este arquivo na raiz do repositório como `AGENTS.md` (ou `CLAUDE.md`, conforme o agente usado) e peça: **"Leia o AGENTS.md inteiro e execute o plano da seção 13, marco por marco."**

---

## 0. Regras para o agente (leia primeiro)

1. Este documento é a **única fonte de verdade**. Tudo o que está aqui deve ser implementado; nada além disso.
2. **Não faça perguntas ao usuário.** Se encontrar uma lacuna, escolha a opção **mais simples** compatível com este documento, registre a decisão em `docs/DECISOES.md` (data, lacuna, escolha, motivo) e continue.
3. **Não adicione funcionalidades fora do escopo (seção 2)**, nem dependências fora da lista (seção 3).
4. Idiomas: **interface, mensagens de erro, README e docs em português do Brasil**. Código (nomes de variáveis, funções, tabelas, colunas, rotas, JSON) em **inglês**. Comentários de código: poucos, em português, só onde a lógica não é óbvia.
5. Mantenha o código **simples e legível** (projeto acadêmico, sem otimização prematura, sem abstrações desnecessárias).
6. Ao final de **cada marco** (seção 13): rode os comandos de verificação, corrija o que falhar e faça um commit. Só avance quando o marco estiver "pronto".
7. **Nunca** use dados reais da BandUp nem de pessoas. Todos os dados de exemplo são fictícios (seção 9).
8. Não declare o projeto concluído sem cumprir a "Definição de pronto" (seção 14).

---

## 1. Contexto

- **Projeto:** CotaLog — IDE de Organização e Cotação de Fretes. Protótipo web acadêmico (Bootcamp UNISAGRADO, módulo *Linguagens de Programação, IDEs e Teorias da Computação*), para a equipe de Planejamento Operacional (Logística) da empresa BandUp.
- **"IDE" aqui** significa **ambiente configurável de domínio**: o usuário da logística configura, **sem escrever código**, a base de custos das transportadoras, os locais e as etapas dos pedidos; o sistema **valida** os dados e **simula/calcula** as cotações.
- **Problema real da empresa:** hoje a equipe cota fretes por WhatsApp e pelo portal das transportadoras. O que mais atrapalha: falta de organização dos outros setores, falta de informação nas solicitações e o grande fluxo de demandas.
- **Como o produto responde:** (a) formulário de pedido com campos obrigatórios e validação → menos falta de informação; (b) cotação automática e comparada → menos trabalho manual; (c) quadro de pedidos por etapas → organização do fluxo.
- **Usuários:** uso local, **um único usuário por vez**, sem login.

## 2. Escopo

### 2.1 Dentro do escopo (implementar tudo)
1. Cadastro de **transportadoras** e **base de custos** (regras de preço por transportadora × região de destino × faixa de peso).
2. Cadastro de **regiões** e **locais** (origens e destinos).
3. Cadastro de **pedidos** com campos obrigatórios e validação.
4. **Cotação automática** com comparativo (menor preço e menor prazo).
5. **Quadro de pedidos** (to-do/kanban) com **etapas configuráveis**.
6. **Exportação em CSV** dos pedidos.
7. Dados de demonstração (seed), testes automatizados do backend, README e docs.

### 2.2 Fora do escopo (NÃO implementar)
Login/permissões, multiusuário, notificações, e-mail/WhatsApp, integração com APIs de transportadoras, cálculo de impostos (ICMS etc.), cubagem/peso cúbico, histórico/auditoria de movimentações, anexos, relatórios/gráficos, internacionalização, deploy em nuvem, Docker, app mobile nativo, tema escuro.

---

## 3. Stack e convenções

| Item | Decisão |
|---|---|
| Runtime | **Node.js ≥ 20**, **npm** (workspaces) |
| Linguagem | **JavaScript (ES Modules)**, sem TypeScript |
| Backend | **Express 4**, **better-sqlite3**, **zod** (validação) |
| Banco | **SQLite**, arquivo `backend/data/cotalog.db` |
| Frontend | **React** (versão estável atual) + **Vite** + **react-router-dom** |
| Estilo | **CSS puro** em `frontend/src/styles.css`. **Sem** bibliotecas de UI, **sem** Tailwind |
| Testes | **vitest** + **supertest** (apenas backend) |
| Dev | **concurrently** (raiz) |

- **Dependências permitidas (e somente estas):** `express`, `better-sqlite3`, `zod`, `react`, `react-dom`, `react-router-dom`, `vite`, `@vitejs/plugin-react`, `vitest`, `supertest`, `concurrently`.
- Use as versões estáveis mais recentes compatíveis com Node 20 e **comite o `package-lock.json`**.
- **Portas:** backend `3001`; frontend (dev) `5173` com **proxy `/api` → `http://localhost:3001`** no `vite.config.js`.
- **JSON da API:** camelCase. **Banco:** snake_case. **Dinheiro:** sempre **inteiro em centavos** (campos `...Cents`). **Datas:** `YYYY-MM-DD` (string). **Timestamps:** ISO 8601 UTC.
- **"Hoje"** = data atual no fuso `America/Sao_Paulo`. Centralize em `backend/src/domain/dates.js` (`todayISO()`), e permita injetar um relógio em `createApp(db, { today })` para testes determinísticos.
- **Formatação na interface:** moeda `Intl.NumberFormat('pt-BR', { style: 'currency', currency: 'BRL' })`; datas `dd/mm/aaaa`; peso com até 3 casas decimais e vírgula decimal. Campos de dinheiro aceitam digitação com vírgula (`72,50`) e convertem para centavos.

## 4. Estrutura do repositório

```
cotalog/
├─ package.json            # workspaces: ["backend","frontend"] + scripts da raiz
├─ README.md
├─ AGENTS.md               # este arquivo
├─ .gitignore              # node_modules, backend/data/*.db, dist, .env
├─ docs/
│  ├─ DECISOES.md
│  └─ REGRA-DE-COTACAO.md
├─ backend/
│  ├─ package.json         # "type": "module"
│  ├─ src/
│  │  ├─ server.js         # sobe o app na porta 3001
│  │  ├─ app.js            # createApp(db, { today })
│  │  ├─ db/ (connection.js, schema.sql, init.js, reset.js, seed.js)
│  │  ├─ domain/ (quote.js, money.js, dates.js)
│  │  ├─ routes/ (carriers, regions, locations, rateRules, stages, orders)
│  │  ├─ middleware/errors.js
│  │  └─ csv.js
│  └─ tests/ (*.test.js)
└─ frontend/
   ├─ package.json, vite.config.js, index.html
   └─ src/ (main.jsx, App.jsx, api.js, format.js, styles.css, pages/, components/)
```

**Scripts da raiz (`package.json`):**
- `npm run dev` → backend e frontend juntos (`concurrently`).
- `npm test` → testes do backend.
- `npm run db:reset` → apaga o arquivo do banco, recria o schema e popula os dados de demonstração.
- `npm run build` → build do frontend.
- `npm start` → build do frontend + backend servindo `frontend/dist` em `http://localhost:3001` (para demonstração).

**Scripts do backend:** `dev` = `node --watch src/server.js`; `start` = `node src/server.js`; `test` = `vitest run`; `db:reset` = `node src/db/reset.js`.
Variável `DB_PATH` define o arquivo do banco (padrão `backend/data/cotalog.db`; os testes usam `:memory:`).

**Inicialização do banco:** ao subir, o servidor executa `schema.sql` (idempotente) e, **se a tabela `stages` estiver vazia, insere as 5 etapas padrão** (seção 6.4). Os dados de demonstração (transportadoras, regiões, locais, regras, pedidos) entram **somente** via `npm run db:reset`.

---

## 5. Banco de dados (`backend/src/db/schema.sql`)

Use exatamente este schema (`PRAGMA foreign_keys = ON;` em toda conexão):

```sql
CREATE TABLE IF NOT EXISTS carriers (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  name TEXT NOT NULL UNIQUE COLLATE NOCASE,
  active INTEGER NOT NULL DEFAULT 1,
  created_at TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS regions (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  name TEXT NOT NULL UNIQUE COLLATE NOCASE
);

CREATE TABLE IF NOT EXISTS locations (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  name TEXT NOT NULL COLLATE NOCASE,
  uf TEXT NOT NULL,
  region_id INTEGER NOT NULL REFERENCES regions(id) ON DELETE RESTRICT,
  UNIQUE (name, uf)
);

CREATE TABLE IF NOT EXISTS rate_rules (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  carrier_id INTEGER NOT NULL REFERENCES carriers(id) ON DELETE CASCADE,
  region_id INTEGER NOT NULL REFERENCES regions(id) ON DELETE RESTRICT,
  min_weight_kg REAL NOT NULL,          -- exclusivo
  max_weight_kg REAL NOT NULL,          -- inclusivo
  price_per_kg_cents INTEGER NOT NULL,
  min_charge_cents INTEGER NOT NULL,
  fixed_fee_cents INTEGER NOT NULL,
  lead_time_days INTEGER NOT NULL
);

CREATE TABLE IF NOT EXISTS stages (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  name TEXT NOT NULL UNIQUE COLLATE NOCASE,
  position INTEGER NOT NULL,
  is_initial INTEGER NOT NULL DEFAULT 0,
  is_final INTEGER NOT NULL DEFAULT 0
);

CREATE TABLE IF NOT EXISTS orders (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  requester_sector TEXT NOT NULL,
  requester_name TEXT NOT NULL,
  origin_location_id INTEGER NOT NULL REFERENCES locations(id) ON DELETE RESTRICT,
  destination_location_id INTEGER NOT NULL REFERENCES locations(id) ON DELETE RESTRICT,
  weight_kg REAL NOT NULL,
  volume_m3 REAL,
  desired_deadline_date TEXT NOT NULL,
  notes TEXT,
  stage_id INTEGER NOT NULL REFERENCES stages(id) ON DELETE RESTRICT,
  created_at TEXT NOT NULL DEFAULT (datetime('now')),
  updated_at TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS quotes (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  order_id INTEGER NOT NULL REFERENCES orders(id) ON DELETE CASCADE,
  carrier_id INTEGER NOT NULL REFERENCES carriers(id) ON DELETE RESTRICT,
  carrier_name TEXT NOT NULL,           -- cópia (snapshot) do nome na hora da cotação
  available INTEGER NOT NULL,
  unavailable_reason TEXT,
  price_cents INTEGER,
  lead_time_days INTEGER,
  estimated_delivery_date TEXT,
  is_selected INTEGER NOT NULL DEFAULT 0,
  created_at TEXT NOT NULL DEFAULT (datetime('now'))
);
CREATE UNIQUE INDEX IF NOT EXISTS one_selected_quote_per_order
  ON quotes(order_id) WHERE is_selected = 1;
```

Atualize `orders.updated_at` a cada alteração do pedido (inclusive mudança de etapa e seleção de cotação).

---

## 6. Regras de negócio

### 6.1 Faixas de peso e regras de preço
- Uma regra vale para **uma transportadora + uma região de destino + uma faixa de peso**.
- A faixa é **`(min, max]`**: casa quando `min_weight_kg < peso <= max_weight_kg`. Faixas adjacentes (`0–10` e `10–50`) são válidas.
- **Não pode haver sobreposição** entre faixas da mesma transportadora na mesma região: duas faixas `A` e `B` se sobrepõem quando `A.min < B.max && B.min < A.max`.
- **A origem do pedido NÃO entra no cálculo** (só a região do destino). A origem é informativa.

### 6.2 Cálculo da cotação (`backend/src/domain/quote.js`, função pura)
Para cada **transportadora ativa** (ordem alfabética), dado o pedido:

1. Se a transportadora **não tem nenhuma regra** para a região do destino → cotação **indisponível**, motivo exato: `"Sem tabela para a região de destino"`.
2. Se tem regras para a região, mas **nenhuma faixa casa com o peso** → indisponível, motivo exato: `"Peso fora das faixas cadastradas"`.
3. Se uma faixa casa → disponível, com:
   - `weightGrams = Math.round(weightKg * 1000)`
   - `variableCents = Math.floor((weightGrams * pricePerKgCents + 500) / 1000)`  *(arredondamento meio-para-cima, só aritmética inteira)*
   - `priceCents = Math.max(minChargeCents, variableCents) + fixedFeeCents`
   - `leadTimeDays = lead_time_days` da regra
   - `estimatedDeliveryDate = hoje + leadTimeDays` (**dias corridos**)
4. `meetsDeadline = estimatedDeliveryDate <= desiredDeadlineDate`. **Não é gravado**: é calculado a cada leitura (o prazo do pedido pode mudar).
5. **Selos** (calculados na leitura, entre as cotações **disponíveis**): `cheapest` = menor `priceCents` (empates recebem o selo); `fastest` = menor `leadTimeDays` (empates recebem o selo).
6. **Ordenação** ao listar: disponíveis primeiro (preço crescente, depois prazo crescente, depois nome); indisponíveis por último (nome).
7. Se nenhuma disponível atende ao prazo, a tela mostra o aviso **"Nenhuma transportadora atende ao prazo desejado."**

### 6.3 Regras de fluxo do pedido
- Todo pedido novo nasce na **etapa inicial**.
- **R1 — Sair da etapa inicial exige cotação selecionada.** Mover um pedido que está na etapa inicial para qualquer outra etapa sem cotação selecionada → **409**, mensagem: `"Selecione uma cotação antes de avançar o pedido."`
- **R2 — Travas na etapa inicial.** Alterar `weightKg`, `originLocationId` ou `destinationLocationId`, **cotar/recotar** e **remover a seleção** só são permitidos com o pedido **na etapa inicial**; fora dela → **409**, mensagem: `"Só é possível alterar peso, origem ou destino, recotar ou remover a seleção enquanto o pedido está na etapa inicial."`
- Alterar `weightKg`, origem ou destino (na etapa inicial) **apaga todas as cotações** do pedido (inclusive a selecionada).
- Os demais campos (setor, solicitante, prazo, volume, observações) podem ser alterados em qualquer etapa.
- Voltar um pedido para a etapa inicial é sempre permitido (não apaga cotações).
- **Cotar** (`POST /api/orders/:id/quotes`): apaga as cotações atuais do pedido e grava uma nova rodada (uma linha por transportadora ativa, inclusive as indisponíveis).
- **Selecionar** uma cotação: só se `available = 1`, senão **409** `"Esta transportadora não atende este pedido."`. Selecionar outra substitui a anterior. Cotação fora do prazo **pode** ser selecionada (a interface pede confirmação).
- Excluir pedido: sempre permitido (as cotações vão junto).

### 6.4 Etapas configuráveis
- **Etapas padrão** (nesta ordem): `A cotar` (**inicial**), `Cotado`, `Aguardando aprovação`, `Despachado`, `Entregue` (**final**).
- Sempre existe **exatamente uma etapa inicial e exatamente uma final**, e nenhuma etapa é as duas coisas.
- Criar etapa: entra no **fim** da ordem. Se vier `isInitial: true` (ou `isFinal: true`), a anterior perde a marca.
- Desmarcar diretamente a etapa inicial/final → **409**: `"Defina outra etapa como inicial em vez de desmarcar esta."` (e `"…como final…"`).
- Reordenar: `PUT /api/stages/order` com **todos** os ids na nova ordem; posições viram 1..n.
- Excluir etapa: **409** se for a inicial ou a final (`"Não é possível excluir a etapa inicial ou a final."`) ou se houver pedidos nela (`"Mova os pedidos desta etapa antes de excluí-la."`).
- Nome da etapa: 2–30 caracteres, único (sem diferenciar maiúsculas/minúsculas).

### 6.5 Validações dos cadastros (todas no backend; o frontend só espelha e exibe)
| Entidade | Regras |
|---|---|
| Transportadora | `name` 2–80 caracteres, único |
| Região | `name` 2–40 caracteres, único |
| Local | `name` 2–80; `uf` = uma das 27 UFs (maiúsculas); `regionId` existente; único por (`name`, `uf`) |
| Regra de custo | `carrierId` e `regionId` existentes; `minWeightKg` ≥ 0; `maxWeightKg` > `minWeightKg` e ≤ 100000; `pricePerKgCents` inteiro ≥ 1; `minChargeCents` e `fixedFeeCents` inteiros ≥ 0; `leadTimeDays` inteiro 1–60; **sem sobreposição** (6.1) |
| Pedido | **Obrigatórios:** `requesterSector` (2–60), `requesterName` (2–80), `originLocationId`, `destinationLocationId` (diferentes da origem), `weightKg` (> 0, ≤ 100000, até 3 casas decimais), `desiredDeadlineDate` (data válida; **na criação** não pode ser anterior a hoje). **Opcionais:** `volumeM3` (> 0, ≤ 1000, até 3 casas; apenas informativo), `notes` (até 500) |

**Mensagens de campo (400):** vazio → `"Campo obrigatório."`; fora de faixa/tamanho → mensagem específica em português (ex.: `"Informe um peso maior que zero."`). Origem = destino → campo `destinationLocationId`: `"Origem e destino devem ser diferentes."`. Sobreposição de faixa → `"Já existe uma faixa de peso dessa transportadora para essa região que se sobrepõe a esta."`. Nome duplicado → **409**, `fields.name`: `"Já existe um registro com este nome."`.

**Exclusões bloqueadas (409):**
- Transportadora com cotações registradas: `"Esta transportadora possui cotações registradas. Desative-a em vez de excluir."` (sem cotações: exclui e **apaga suas regras em cascata**).
- Região usada por locais ou regras: `"Esta região está em uso por locais ou regras de custo."`
- Local usado por pedidos: `"Este local está em uso por pedidos."`
- Regra de custo: sempre pode excluir.

---

## 7. API REST (prefixo `/api`, JSON)

**Formato de erro (sempre):**
```json
{ "error": { "code": "VALIDATION_ERROR", "message": "Dados inválidos.", "fields": { "weightKg": "Informe um peso maior que zero." } } }
```
Códigos: `VALIDATION_ERROR` (400), `NOT_FOUND` (404), `CONFLICT` (409). Erros inesperados: 500 com `{ "error": { "code": "INTERNAL_ERROR", "message": "Erro interno." } }` (sem stack trace). `fields` é omitido quando não se aplica.

| Método e rota | Função | Sucesso |
|---|---|---|
| `GET /api/health` | `{ "status": "ok" }` | 200 |
| `GET /api/carriers` | lista (ordem alfabética) | 200 |
| `POST /api/carriers` | `{ name }` (nasce ativa) | 201 |
| `PATCH /api/carriers/:id` | `{ name?, active? }` | 200 |
| `DELETE /api/carriers/:id` | exclui (6.5) | 204 |
| `GET/POST /api/regions`, `PATCH/DELETE /api/regions/:id` | CRUD de `{ name }` | 200/201/204 |
| `GET/POST /api/locations`, `PATCH/DELETE /api/locations/:id` | CRUD de `{ name, uf, regionId }`; resposta inclui `regionName` | 200/201/204 |
| `GET /api/rate-rules?carrierId=&regionId=` | lista (filtros opcionais), ordenada por transportadora, região, `minWeightKg` | 200 |
| `POST /api/rate-rules` · `PATCH` · `DELETE /api/rate-rules/:id` | CRUD (6.5) | 201/200/204 |
| `GET /api/stages` | lista por `position` | 200 |
| `POST /api/stages` | `{ name, isInitial?, isFinal? }` | 201 |
| `PATCH /api/stages/:id` | `{ name?, isInitial?, isFinal? }` | 200 |
| `PUT /api/stages/order` | `{ ids: [..] }` (todos os ids) | 200 (lista) |
| `DELETE /api/stages/:id` | exclui (6.4) | 204 |
| `GET /api/orders?search=` | lista de pedidos (resumo) | 200 |
| `POST /api/orders` | cria (6.5) na etapa inicial | 201 |
| `GET /api/orders/:id` | pedido + `quotes` | 200 |
| `PATCH /api/orders/:id` | edita (6.3 R2) | 200 |
| `DELETE /api/orders/:id` | exclui | 204 |
| `POST /api/orders/:id/stage` | `{ stageId }` move (6.3 R1) | 200 |
| `POST /api/orders/:id/quotes` | cota/recota (6.2, 6.3) | 201 `{ quotes: [...] }` |
| `POST /api/orders/:id/quotes/:quoteId/select` | seleciona cotação | 200 (pedido completo) |
| `DELETE /api/orders/:id/selection` | remove a seleção (R2) | 200 (pedido completo) |
| `GET /api/orders/export.csv` | CSV (seção 10) | 200 |

**Formato do pedido (resposta):**
```json
{
  "id": 1, "code": "PED-0001",
  "requesterSector": "Comercial", "requesterName": "Marina Souza",
  "origin": { "id": 1, "name": "CD Central (fictício)", "uf": "SP" },
  "destination": { "id": 3, "name": "Campinas", "uf": "SP", "regionId": 1, "regionName": "Sudeste" },
  "weightKg": 20, "volumeM3": null,
  "desiredDeadlineDate": "2026-11-17", "notes": null,
  "stage": { "id": 1, "name": "A cotar", "isInitial": true, "isFinal": false },
  "selectedQuote": null,
  "quotesCount": 0,
  "createdAt": "…", "updatedAt": "…"
}
```
`code` = `"PED-"` + id com 4 dígitos (zeros à esquerda). `GET /api/orders/:id` acrescenta `quotes: [...]`.

**Formato da cotação:**
```json
{ "id": 10, "carrierId": 3, "carrierName": "Gama Cargas", "available": true,
  "unavailableReason": null, "priceCents": 6300, "leadTimeDays": 5,
  "estimatedDeliveryDate": "2026-11-15", "meetsDeadline": true,
  "isSelected": false, "badges": ["cheapest"] }
```
`selectedQuote` no pedido usa o mesmo formato (ou `null`). `badges` ∈ `["cheapest","fastest"]` (pode ter os dois ou nenhum).

**Atenção à ordem das rotas:** declare `GET /api/orders/export.csv` **antes** de `GET /api/orders/:id`.

**Listagem de pedidos:** `search` filtra por substring, sem diferenciar maiúsculas de minúsculas, em: `code`, `requesterName`, `requesterSector`, nome da origem, nome do destino, nome da transportadora selecionada. Ordem padrão: `desiredDeadlineDate` crescente, depois `id`.

---

## 8. Frontend

### 8.1 Layout e estilo
- Tipografia do sistema (`system-ui`). Paleta: primária `#1F4E79`, destaque `#2E8B57`, fundo `#F5F7FA`, texto `#1B1F24`, borda `#D8DEE6`, erro `#B3261E`, aviso `#B26A00`.
- **Barra lateral** (220 px) com o nome **CotaLog** e o subtítulo "IDE de Organização e Cotação de Fretes", e links: **Pedidos**, **Base de custos**, **Locais**, **Etapas**. Abaixo de 768 px vira barra superior. Deve ser usável em 360 px de largura.
- Rodapé discreto: "Protótipo acadêmico — UNISAGRADO". **Não usar logotipo da BandUp.**
- Toda tela tem estados de **carregando**, **vazio** (texto explicativo) e **erro** (mensagem vinda da API).
- Erros de campo (`fields`) aparecem **abaixo do campo**; mensagens gerais (409) aparecem em um **aviso no topo da tela** (`role="alert"`), que some após 6 s ou ao clicar em fechar.
- Excluir sempre pede `window.confirm("Tem certeza que deseja excluir …?")`.
- Campos com `label` associado, foco visível, botões com texto (sem apenas ícones).

### 8.2 Rotas
| Rota | Tela |
|---|---|
| `/` | redireciona para `/pedidos` |
| `/pedidos` | Quadro de pedidos |
| `/pedidos/novo` | Formulário de novo pedido |
| `/pedidos/:id` | Detalhe do pedido + cotação |
| `/pedidos/:id/editar` | Formulário de edição |
| `/base-de-custos` | Transportadoras e regras |
| `/locais` | Regiões e locais |
| `/etapas` | Etapas |

### 8.3 Quadro de pedidos (`/pedidos`)
- Uma **coluna por etapa**, na ordem das etapas; o título mostra **nome + quantidade** (ex.: "A cotar (4)").
- Barra superior: campo **Buscar** (usa `?search=`, com 300 ms de debounce), botão **Novo pedido**, botão **Exportar CSV** (baixa `/api/orders/export.csv`).
- **Cartão do pedido:** código, solicitante e setor, `origem → destino`, peso (kg), prazo desejado (`dd/mm/aaaa`), e **selo**: transportadora + valor (se houver seleção) ou "Sem cotação". Se `desiredDeadlineDate < hoje` e a etapa **não** é a final → destaque de **atrasado** (borda `#B3261E` + texto "Prazo vencido").
- **Mover:** arrastar o cartão para outra coluna (HTML5 drag-and-drop nativo) **e** um `select` "Mover para…" no cartão (acessibilidade/celular). Chama `POST /api/orders/:id/stage`; em caso de 409, o cartão **volta** à coluna original e o aviso mostra a mensagem da API.
- Clicar no cartão (fora do `select`) abre `/pedidos/:id`.
- Colunas ordenadas por prazo desejado crescente.

### 8.4 Formulário de pedido
Campos, na ordem: Setor solicitante (texto com `datalist` sugerindo os setores já usados e, se vazio, `Comercial`, `Compras`, `Financeiro`, `Produção`, `Atendimento`), Nome do solicitante, Origem (select de locais), Destino (select de locais), Peso (kg), Volume (m³, opcional), Prazo desejado (`input type="date"`), Observações (opcional). Obrigatórios marcados com `*`. Botões **Salvar** e **Cancelar**. Na edição, se o pedido **não** está na etapa inicial, os campos Peso, Origem e Destino ficam **desabilitados** com a dica "Disponível apenas na etapa inicial". Após criar, vai para `/pedidos/:id`.

### 8.5 Detalhe do pedido (`/pedidos/:id`)
1. **Dados do pedido** (leitura) + botões **Editar** e **Excluir**.
2. **Etapa:** `select` para mover (mesmas regras/avisos do quadro).
3. **Cotação de frete:** botão **Cotar frete** (vira **Recotar** se já houver cotações; desabilitado fora da etapa inicial, com dica). Tabela: **Transportadora | Valor | Prazo (dias) | Entrega estimada | Prazo | Ação**.
   - Selos: "Mais barata" e "Mais rápida" ao lado do nome.
   - Coluna **Prazo**: "No prazo" (verde) ou "Fora do prazo" (aviso).
   - Indisponíveis: linha cinza, valor "—", motivo na coluna Prazo; sem botão.
   - Ação: **Selecionar**. Se fora do prazo → `window.confirm("Esta opção não atende ao prazo desejado. Selecionar mesmo assim?")`.
   - Selecionada: linha destacada + texto "Selecionada" + botão **Remover seleção** (desabilitado fora da etapa inicial).
   - Sem transportadoras ativas: "Nenhuma transportadora ativa cadastrada. Cadastre em Base de custos."
   - Se nenhuma disponível atende ao prazo: aviso "Nenhuma transportadora atende ao prazo desejado."

### 8.6 Base de custos (`/base-de-custos`)
- **Transportadoras:** lista com nome, interruptor **Ativa**, botões Renomear (edição inline) e Excluir; formulário "Nova transportadora".
- Ao **clicar em uma transportadora**, abre o painel de **regras de custo** dela: tabela (Região | De (kg, exclusivo) | Até (kg) | R$/kg | Mínimo (R$) | Taxa fixa (R$) | Prazo (dias) | Ações), filtro por região, formulário **Nova regra** (todos os campos de 6.5) e edição/exclusão por linha. Erros de sobreposição aparecem no formulário.
- Valores em reais na interface; conversão para centavos ao enviar.

### 8.7 Locais (`/locais`)
Duas seções: **Regiões** (lista + formulário + renomear/excluir) e **Locais** (tabela Nome | UF | Região + formulário com select de UF e de região + editar/excluir).

### 8.8 Etapas (`/etapas`)
Lista ordenada com: nome (edição inline), botões **↑ / ↓** (reordenam via `PUT /api/stages/order`), marcação **Inicial** e **Final** (botões de rádio — escolher outra etapa transfere a marca) e **Excluir**. Formulário "Nova etapa". Texto de ajuda: "Todo pedido novo entra na etapa inicial. Para avançar, é preciso selecionar uma cotação."

---

## 9. Dados de demonstração (`backend/src/db/seed.js`) — todos fictícios

O seed **apaga os dados** e recria tudo. Etapas padrão (6.4). Pesos/preços abaixo são **exatos**; os testes dependem deles.

**Regiões:** Sudeste, Sul, Centro-Oeste, Nordeste, Norte.

**Locais (nome — UF — região):** CD Central (fictício) — SP — Sudeste; São Paulo — SP — Sudeste; Campinas — SP — Sudeste; Bauru — SP — Sudeste; Rio de Janeiro — RJ — Sudeste; Belo Horizonte — MG — Sudeste; Curitiba — PR — Sul; Porto Alegre — RS — Sul; Goiânia — GO — Centro-Oeste; Salvador — BA — Nordeste; Manaus — AM — Norte.

**Transportadoras (todas ativas):** `Alfa Transportes`, `Beta Express`, `Gama Cargas`, `Delta Log`.

**Faixas de peso (kg):** B1 = (0, 10]; B2 = (10, 50]; B3 = (50, 200]; B4 = (200, 1000].

**Preço base por kg na região Sudeste (centavos) por faixa B1 / B2 / B3 / B4, mínimo, taxa fixa, prazo base (dias):**

| Transportadora | B1 | B2 | B3 | B4 | Mínimo | Taxa fixa | Prazo base |
|---|---|---|---|---|---|---|---|
| Alfa Transportes | 450 | 320 | 240 | 180 | 4500 | 800 | 3 |
| Beta Express | 420 | 350 | 210 | **sem B4** | 4000 | 1200 | 2 |
| Gama Cargas | 400 | 290 | 230 | 160 | 5000 | 500 | 5 |
| Delta Log | 480 | 300 | 220 | 190 | 3800 | 1000 | 4 |

**Multiplicadores por região de destino** (percentual inteiro aplicado ao preço por kg; **dias extras** somados ao prazo base):
Sudeste 100 / +0 · Sul 115 / +1 · Centro-Oeste 120 / +2 · Nordeste 145 / +3 · Norte 170 / +5.

**Geração das regras:** para cada transportadora × região × faixa existente: `pricePerKgCents = Math.round(base * percentual / 100)` (aritmética inteira; `x.5` arredonda para cima); `minChargeCents` e `fixedFeeCents` iguais em todas as regiões; `leadTimeDays = prazoBase + diasExtras`. **Exceção:** `Delta Log` **não tem regras para Norte**. (Beta não tem B4 em nenhuma região.)

**Pedidos de exemplo** (origem sempre `CD Central (fictício)`; prazos = data do seed + N dias). Para os pedidos 3–6 o seed **chama o mesmo serviço de cotação**, seleciona a transportadora indicada e move o pedido para a etapa indicada; os demais ficam sem cotação na etapa inicial:

| # | Setor | Solicitante | Destino | Peso (kg) | Prazo | Etapa | Transportadora selecionada |
|---|---|---|---|---|---|---|---|
| 1 | Comercial | Marina Souza | Campinas | 20 | +7 | A cotar | — |
| 2 | Compras | Carlos Lima | Curitiba | 5 | +10 | A cotar | — |
| 3 | Atendimento | Paula Reis | Salvador | 300 | +15 | Cotado | Gama Cargas |
| 4 | Produção | João Alves | Rio de Janeiro | 45,5 | +6 | Aguardando aprovação | Beta Express |
| 5 | Comercial | Marina Souza | Porto Alegre | 120 | +12 | Despachado | Alfa Transportes |
| 6 | Compras | Carlos Lima | Goiânia | 8 | +9 | Entregue | Delta Log |
| 7 | Atendimento | Paula Reis | Belo Horizonte | 60 | +4 | A cotar | — |
| 8 | Produção | João Alves | Manaus | 15 | +20 | A cotar | — |

### 9.1 Exemplos numéricos oficiais (usar nos testes; `hoje` = `2026-11-10`)

**E1 — Campinas (Sudeste), 20 kg (faixa B2):**
Alfa R$ 72,00 / 3 d · Beta R$ 82,00 / 2 d · Gama R$ 63,00 / 5 d · Delta R$ 70,00 / 4 d. Mais barata: **Gama**. Mais rápida: **Beta**.
(ex.: Alfa = max(4500; 20 × 320 = 6400) + 800 = **7200** centavos.)

**E2 — Sudeste, 5 kg (B1; vale o mínimo):**
Alfa R$ 53,00 · Beta R$ 52,00 · Gama R$ 55,00 · Delta R$ 48,00 (prazos 3 / 2 / 5 / 4). Mais barata: **Delta**.

**E3 — Salvador (Nordeste), 300 kg (B4):**
Alfa R$ 791,00 / 6 d · Gama R$ 701,00 / 8 d · Delta R$ 838,00 / 7 d · **Beta indisponível: "Peso fora das faixas cadastradas"**. Mais barata: **Gama**. Mais rápida: **Alfa**.
(Delta: 190 × 145 / 100 = 275,5 → **276**; 300 × 276 = 82800; + 1000 = **83800**.)

**E4 — Manaus (Norte), 15 kg (B2):**
Alfa R$ 89,60 / 8 d · Beta R$ 101,25 / 7 d · Gama R$ 78,95 / 10 d · **Delta indisponível: "Sem tabela para a região de destino"**. Mais barata: **Gama**. Mais rápida: **Beta**.

**E5 — Belo Horizonte (Sudeste), 60 kg (B3), prazo desejado = hoje + 4:**
Alfa R$ 152,00 / 3 d · Beta R$ 138,00 / 2 d · Gama R$ 143,00 / 5 d · Delta R$ 142,00 / 4 d. **Gama "Fora do prazo"** (entrega estimada hoje + 5 > prazo). **Beta** recebe os dois selos.

**E6 — Arredondamento:** peso 12,345 kg com `pricePerKgCents = 368` → `weightGrams = 12345`; `Math.floor((12345 × 368 + 500) / 1000)` = **4543**.

---

## 10. Exportação CSV (`GET /api/orders/export.csv`)

- Cabeçalhos HTTP: `Content-Type: text/csv; charset=utf-8` e `Content-Disposition: attachment; filename="cotalog-pedidos.csv"`.
- Arquivo em **UTF-8 com BOM** (`\uFEFF` no início), separador **`;`**, quebra de linha **`\r\n`**, decimais com **vírgula**, datas `dd/mm/aaaa`.
- **Colunas, nesta ordem:** `Código;Setor;Solicitante;Origem;Destino;Região de destino;Peso (kg);Volume (m³);Prazo desejado;Etapa;Transportadora selecionada;Valor (R$);Prazo da transportadora (dias);Entrega estimada;Criado em`.
- Sem cotação selecionada: as colunas de transportadora, valor, prazo e entrega ficam **vazias**.
- Células que contenham `;`, `"` ou quebra de linha vão entre aspas, com `"` duplicado. Células de texto que **começam com `=`, `+`, `-` ou `@`** recebem um apóstrofo (`'`) na frente (proteção contra injeção de fórmulas).
- Respeita o mesmo ordenamento da listagem de pedidos e **ignora** `search`.

---

## 11. Testes (backend, `vitest` + `supertest`, banco `:memory:`, `today = '2026-11-10'`)

Obrigatórios (todos devem passar):
1. **Cálculo (unitário):** E1, E2, E3, E4, E5 e E6 da seção 9.1, incluindo selos, ordenação, indisponibilidade e `meetsDeadline`.
2. **Faixas:** limites `(min, max]` (peso = max casa; peso = min não casa), faixas adjacentes aceitas, sobreposição rejeitada (**400** com `fields`, mensagem da seção 6.5).
3. **Validações de pedido:** campos obrigatórios, origem = destino, peso ≤ 0, mais de 3 casas decimais, prazo no passado na criação.
4. **Fluxo:** R1 (sair da etapa inicial sem seleção → 409), R2 (editar peso/origem/destino, cotar e remover seleção fora da etapa inicial → 409), selecionar cotação indisponível → 409, alterar peso na etapa inicial apaga cotações.
5. **Etapas:** criar, trocar inicial/final, desmarcar direto → 409, reordenar, excluir com pedidos → 409, excluir inicial/final → 409.
6. **Exclusões bloqueadas:** transportadora com cotações, região em uso, local em uso.
7. **CSV:** BOM presente, separador `;`, ordem das colunas, escape de `;`/`"`, proteção contra `=`/`+`/`-`/`@`, vírgula decimal.
8. **Seed:** após o seed, existem 4 transportadoras, 5 regiões, 11 locais, 8 pedidos e as quantidades por etapa da seção 14 (passo 1).

Frontend: **sem testes automatizados**; é validado pelo roteiro da seção 14.

---

## 12. Documentação a entregar

- **`README.md`** (pt-BR): o que é; requisitos (Node ≥ 20); instalação (`npm install`); como rodar (`npm run db:reset`, `npm run dev`, `npm start`); testes (`npm test`); estrutura de pastas; resumo das funcionalidades; regra de cotação (resumo + link para `docs/REGRA-DE-COTACAO.md`); limitações (seção 2.2); aviso "dados fictícios".
- **`docs/REGRA-DE-COTACAO.md`:** fórmula, faixas `(min, max]`, arredondamento, selos, prazo, motivos de indisponibilidade e os exemplos E1–E6.
- **`docs/DECISOES.md`:** todas as lacunas resolvidas (seção 0, regra 2). Se nenhuma, escreva "Nenhuma lacuna encontrada."

---

## 13. Plano de execução (marcos)

**M0 — Base do projeto.** Repositório git; workspaces; scripts da raiz; `.gitignore`; backend com `GET /api/health`; frontend Vite com proxy `/api` e a casca (barra lateral + rotas vazias).
*Pronto quando:* `npm install` e `npm run dev` sobem, e `http://localhost:5173/api/health` retorna `{"status":"ok"}`. Commit: `chore: estrutura inicial do projeto`.

**M1 — Banco, domínio e seed.** `schema.sql`, `init.js`, `reset.js`, `seed.js`, `money.js`, `dates.js`, `quote.js` + testes 1 e 8 (parcial) da seção 11.
*Pronto quando:* `npm run db:reset` cria o banco com os dados da seção 9 e os testes de cálculo (E1–E6) passam. Commit: `feat: schema, seed e regra de cotação`.

**M2 — API de cadastros.** Transportadoras, regiões, locais, regras de custo, etapas, middleware de erros, validações com zod, testes 2, 5 e 6.
*Pronto quando:* testes passam e as rotas respondem conforme a seção 7. Commit: `feat: api de cadastros e etapas`.

**M3 — API de pedidos.** CRUD de pedidos, mover etapa, cotar, selecionar/remover seleção, listagem com `search`, CSV; testes 3, 4, 7 e 8.
*Pronto quando:* `npm test` 100 % verde. Commit: `feat: api de pedidos, cotação e csv`.

**M4 — Frontend: cadastros.** `api.js`, `format.js`, componentes comuns (aviso, estados, formulários), telas Base de custos, Locais e Etapas (seções 8.6–8.8).
*Pronto quando:* é possível cadastrar/editar/excluir tudo pelas telas, com erros da API exibidos. Commit: `feat: telas de cadastros`.

**M5 — Frontend: pedidos.** Quadro com arrastar e soltar + `select`, busca, exportar CSV, formulário, detalhe com cotação (seções 8.3–8.5).
*Pronto quando:* o roteiro da seção 14 (passos 1–10) passa. Commit: `feat: quadro de pedidos e cotação`.

**M6 — Acabamento.** Responsividade (360 px), estados de vazio/erro, acessibilidade básica, README e docs (seção 12), revisão de dependências (somente as permitidas), `npm start` funcionando em `http://localhost:3001`.
*Pronto quando:* "Definição de pronto" (seção 14) 100 % cumprida. Commit: `docs: readme, documentação e acabamento`.

---

## 14. Definição de pronto e roteiro de aceitação

### 14.1 Checklist técnico
- [ ] `npm install` sem erros; `package-lock.json` comitado.
- [ ] `npm run db:reset` popula o banco conforme a seção 9.
- [ ] `npm test` verde (todos os testes da seção 11).
- [ ] `npm run dev` abre em `http://localhost:5173`; `npm start` serve tudo em `http://localhost:3001`.
- [ ] Nenhuma dependência além das permitidas; nenhum dado real; `.db` fora do git.
- [ ] README, `docs/REGRA-DE-COTACAO.md` e `docs/DECISOES.md` presentes.

### 14.2 Roteiro de aceitação (após `npm run db:reset`; `hoje` = data do seed)
1. **Quadro:** 5 colunas — A cotar (4: PED-0001, 0002, 0007, 0008), Cotado (1: PED-0003), Aguardando aprovação (1: PED-0004), Despachado (1: PED-0005), Entregue (1: PED-0006).
2. **Cotar PED-0001:** 4 linhas conforme **E1** (Gama "Mais barata", Beta "Mais rápida", todas "No prazo").
3. **Selecionar Gama** em PED-0001 → linha destacada; mover o pedido para **Cotado** funciona (por arrastar e pelo `select`).
4. **PED-0002 sem seleção:** tentar movê-lo para Cotado → o cartão volta e aparece **"Selecione uma cotação antes de avançar o pedido."**
5. **PED-0007:** cotar → conforme **E5** (Gama "Fora do prazo"; Beta com os dois selos); selecionar Gama pede confirmação.
6. **PED-0008:** cotar → conforme **E4** (Delta "Sem tabela para a região de destino"; Gama mais barata; Beta mais rápida).
7. **PED-0003 (Cotado):** editar o peso é bloqueado (campo desabilitado) e "Recotar" está desabilitado.
8. **Novo pedido** com origem = destino → erro **"Origem e destino devem ser diferentes."** abaixo do campo; sem peso → "Campo obrigatório.".
9. **Base de custos:** criar para Alfa/Sudeste a faixa 5–15 kg → erro de sobreposição; criar uma faixa válida de 1000–2000 kg → salva.
10. **Etapas:** adicionar "Em separação"; reordená-la com ↑/↓; tentar excluir "A cotar" → erro (inicial); tentar excluir "Cotado" (tem PED-0003) → "Mova os pedidos desta etapa antes de excluí-la."
11. **Exportar CSV:** o arquivo abre no Excel com acentos corretos, 8 pedidos, separador `;`, valores com vírgula.
12. **Responsivo:** em 360 px nada fica cortado e todas as telas continuam utilizáveis.

Ao terminar, responda ao usuário com: (a) lista do que foi entregue por marco, (b) resultado de `npm test`, (c) o conteúdo de `docs/DECISOES.md`, (d) como rodar o projeto (3 comandos).
